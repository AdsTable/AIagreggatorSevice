"""
Production-ready configuration management
"""
import os
from typing import Dict, Any
from dataclasses import dataclass
from enum import Enum

class DeploymentEnvironment(Enum):
    LOCAL = "local"
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"

@dataclass
class JsonSafeProductionConfig:
    """Production configuration with environment-specific settings"""
    
    # Core JSON safety settings
    positive_inf_replacement: float
    negative_inf_replacement: float
    nan_strategy: str  # 'null', 'zero', 'string'
    
    # Performance settings
    enable_logging: bool
    enable_metrics: bool
    cache_size: int
    batch_size: int
    
    # Monitoring settings
    enable_tracing: bool
    metrics_endpoint: str
    log_level: str
    
    # Safety settings
    strict_validation: bool
    fail_on_unsafe_data: bool
    max_recursion_depth: int

class ConfigManager:
    """Centralized configuration management"""
    
    CONFIGS: Dict[DeploymentEnvironment, JsonSafeProductionConfig] = {
        DeploymentEnvironment.LOCAL: JsonSafeProductionConfig(
            positive_inf_replacement=999999.0,
            negative_inf_replacement=-999999.0,
            nan_strategy='null',
            enable_logging=True,
            enable_metrics=True,
            cache_size=1000,
            batch_size=100,
            enable_tracing=True,
            metrics_endpoint='/metrics',
            log_level='DEBUG',
            strict_validation=True,
            fail_on_unsafe_data=False,
            max_recursion_depth=100
        ),
        
        DeploymentEnvironment.PRODUCTION: JsonSafeProductionConfig(
            positive_inf_replacement=1000000.0,
            negative_inf_replacement=-1000000.0,
            nan_strategy='null',
            enable_logging=False,  # Reduced overhead
            enable_metrics=True,
            cache_size=10000,
            batch_size=1000,
            enable_tracing=True,
            metrics_endpoint='/metrics',
            log_level='WARNING',
            strict_validation=False,  # Performance optimization
            fail_on_unsafe_data=False,
            max_recursion_depth=50
        )
    }
    
    @classmethod
    def get_config(cls, env: DeploymentEnvironment = None) -> JsonSafeProductionConfig:
        """Get configuration for specific environment"""
        if env is None:
            env_name = os.getenv('DEPLOYMENT_ENV', 'local').lower()
            env = DeploymentEnvironment(env_name)
        
        return cls.CONFIGS[env]
    
    @classmethod
    def apply_to_json_safe_config(cls, env: DeploymentEnvironment = None):
        """Apply configuration to global JsonSafeConfig"""
        config = cls.get_config(env)
        
        JsonSafeConfig.POSITIVE_INF_REPLACEMENT = config.positive_inf_replacement
        JsonSafeConfig.NEGATIVE_INF_REPLACEMENT = config.negative_inf_replacement
        JsonSafeConfig.NAN_STRATEGY = config.nan_strategy
        JsonSafeConfig.LOG_CONVERSIONS = config.enable_logging
        
        return config

# Auto-apply configuration on import
production_config = ConfigManager.apply_to_json_safe_config()