"""
Structured logging configuration for production
"""
import logging
import json
import sys
from datetime import datetime
from typing import Dict, Any

class JsonFormatter(logging.Formatter):
    """JSON formatter for structured logging"""
    
    def format(self, record):
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add extra fields if present
        if hasattr(record, 'extra_fields'):
            log_entry.update(record.extra_fields)
        
        # Add exception information if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry, ensure_ascii=False)

class JsonSafeLogger:
    """Logger specifically for JSON safety operations"""
    
    def __init__(self, name: str = 'json_safe'):
        self.logger = logging.getLogger(name)
        self._setup_logger()
    
    def _setup_logger(self):
        """Setup logger with JSON formatting"""
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)
        
        # Prevent duplicate logs
        self.logger.propagate = False
    
    def log_conversion(self, conversion_type: str, original_value: Any, 
                      converted_value: Any, context: Dict[str, Any] = None):
        """Log a JSON safety conversion"""
        extra_fields = {
            'event_type': 'json_conversion',
            'conversion_type': conversion_type,
            'original_value': str(original_value),
            'converted_value': str(converted_value),
            'context': context or {}
        }
        
        self.logger.info(
            f"JSON conversion: {conversion_type}",
            extra={'extra_fields': extra_fields}
        )
    
    def log_performance(self, operation: str, duration: float, 
                       metrics: Dict[str, Any] = None):
        """Log performance metrics"""
        extra_fields = {
            'event_type': 'performance',
            'operation': operation,
            'duration_seconds': duration,
            'metrics': metrics or {}
        }
        
        self.logger.info(
            f"Performance: {operation} took {duration:.3f}s",
            extra={'extra_fields': extra_fields}
        )
    
    def log_error(self, error_type: str, error_message: str, 
                  context: Dict[str, Any] = None):
        """Log an error with context"""
        extra_fields = {
            'event_type': 'error',
            'error_type': error_type,
            'context': context or {}
        }
        
        self.logger.error(
            f"Error: {error_type} - {error_message}",
            extra={'extra_fields': extra_fields}
        )

# Global logger instance
json_safe_logger = JsonSafeLogger()