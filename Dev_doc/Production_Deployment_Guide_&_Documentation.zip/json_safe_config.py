from enum import Enum
from dataclasses import dataclass
from typing import Optional

class Environment(Enum):
    DEVELOPMENT = "development"
    STAGING = "staging" 
    PRODUCTION = "production"

@dataclass
class EnvironmentConfig:
    """Конфигурация для разных окружений"""
    positive_inf_replacement: float
    negative_inf_replacement: float
    nan_strategy: str
    log_conversions: bool
    strict_validation: bool
    performance_monitoring: bool

class JsonSafeEnvironmentManager:
    """Менеджер конфигураций для разных окружений"""
    
    CONFIGS = {
        Environment.DEVELOPMENT: EnvironmentConfig(
            positive_inf_replacement=999999.0,
            negative_inf_replacement=-999999.0,
            nan_strategy='null',
            log_conversions=True,
            strict_validation=True,
            performance_monitoring=True
        ),
        Environment.STAGING: EnvironmentConfig(
            positive_inf_replacement=999999.0,
            negative_inf_replacement=-999999.0,
            nan_strategy='null',
            log_conversions=True,
            strict_validation=True,
            performance_monitoring=True
        ),
        Environment.PRODUCTION: EnvironmentConfig(
            positive_inf_replacement=1000000.0,
            negative_inf_replacement=-1000000.0,
            nan_strategy='null',
            log_conversions=False,  # Отключаем в продакшене
            strict_validation=False,  # Снижаем overhead
            performance_monitoring=True
        )
    }
    
    @classmethod
    def get_config(cls, env: Environment) -> EnvironmentConfig:
        return cls.CONFIGS[env]
    
    @classmethod
    def apply_config(cls, env: Environment):
        """Применить конфигурацию к JsonSafeConfig"""
        config = cls.get_config(env)
        JsonSafeConfig.POSITIVE_INF_REPLACEMENT = config.positive_inf_replacement
        JsonSafeConfig.NEGATIVE_INF_REPLACEMENT = config.negative_inf_replacement
        JsonSafeConfig.NAN_STRATEGY = config.nan_strategy
        JsonSafeConfig.LOG_CONVERSIONS = config.log_conversions