"""
Prometheus metrics for JSON safety operations
"""
from prometheus_client import Counter, Histogram, Gauge, generate_latest
import time
from typing import Dict, Any

# Metrics definitions
json_conversions_total = Counter(
    'json_safe_conversions_total',
    'Total number of JSON safety conversions',
    ['conversion_type', 'strategy']
)

json_serialization_duration = Histogram(
    'json_safe_serialization_duration_seconds',
    'Time spent on JSON serialization',
    ['data_type', 'size_category']
)

json_safety_errors_total = Counter(
    'json_safe_errors_total',
    'Total number of JSON safety errors',
    ['error_type', 'component']
)

active_products_gauge = Gauge(
    'json_safe_active_products',
    'Number of active products in database'
)

database_query_duration = Histogram(
    'json_safe_database_query_duration_seconds',
    'Database query execution time',
    ['operation', 'index_used']
)

class MetricsCollector:
    """Centralized metrics collection"""
    
    @staticmethod
    def record_conversion(conversion_type: str, strategy: str = 'default'):
        """Record a JSON safety conversion"""
        json_conversions_total.labels(
            conversion_type=conversion_type,
            strategy=strategy
        ).inc()
    
    @staticmethod
    def record_serialization(data_type: str, size: int, duration: float):
        """Record JSON serialization metrics"""
        size_category = 'small' if size < 1000 else 'medium' if size < 10000 else 'large'
        json_serialization_duration.labels(
            data_type=data_type,
            size_category=size_category
        ).observe(duration)
    
    @staticmethod
    def record_error(error_type: str, component: str):
        """Record an error"""
        json_safety_errors_total.labels(
            error_type=error_type,
            component=component
        ).inc()
    
    @staticmethod
    def update_products_count(count: int):
        """Update active products gauge"""
        active_products_gauge.set(count)
    
    @staticmethod
    def record_database_query(operation: str, duration: float, index_used: bool):
        """Record database query metrics"""
        database_query_duration.labels(
            operation=operation,
            index_used=str(index_used)
        ).observe(duration)

# Integration with existing code
def enhanced_json_safe_float_with_metrics(value, log_conversion=None):
    """Enhanced json_safe_float with metrics collection"""
    start_time = time.time()
    
    if value is None:
        return None
    
    if isinstance(value, (int, float)):
        if math.isinf(value):
            conversion_type = 'positive_inf' if value > 0 else 'negative_inf'
            MetricsCollector.record_conversion(conversion_type)
            result = JsonSafeConfig.POSITIVE_INF_REPLACEMENT if value > 0 else JsonSafeConfig.NEGATIVE_INF_REPLACEMENT
        elif math.isnan(value):
            MetricsCollector.record_conversion('nan', JsonSafeConfig.NAN_STRATEGY)
            result = None if JsonSafeConfig.NAN_STRATEGY == 'null' else 0.0
        else:
            result = float(value)
    else:
        result = value
    
    duration = time.time() - start_time
    MetricsCollector.record_serialization('float', 1, duration)
    
    return result