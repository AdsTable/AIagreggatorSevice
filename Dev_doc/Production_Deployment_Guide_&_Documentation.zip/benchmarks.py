"""
Performance benchmarks for JSON safety operations
"""
import time
import statistics
import json
import math
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from complete_json_safe_test_suite import (
    json_safe_float, safe_json_dumps, StandardizedProduct,
    create_comprehensive_test_products
)

@dataclass
class BenchmarkResult:
    """Results of a benchmark test"""
    operation: str
    total_time: float
    avg_time: float
    min_time: float
    max_time: float
    p95_time: float
    p99_time: float
    operations_per_second: float
    memory_usage_mb: float

class JsonSafetyBenchmark:
    """Comprehensive benchmarking suite"""
    
    def __init__(self, iterations: int = 1000):
        self.iterations = iterations
        self.results: List[BenchmarkResult] = []
    
    def benchmark_float_conversion(self) -> BenchmarkResult:
        """Benchmark float conversion performance"""
        test_values = [
            float('inf'), float('-inf'), float('nan'),
            0.0, -0.0, 1e308, -1e308, 1e-308, -1e-308,
            3.14159, -2.71828, 42.0, -42.0
        ]
        
        times = []
        for _ in range(self.iterations):
            start = time.perf_counter()
            for value in test_values:
                json_safe_float(value)
            end = time.perf_counter()
            times.append(end - start)
        
        return self._calculate_stats('float_conversion', times, len(test_values))
    
    def benchmark_json_serialization(self) -> BenchmarkResult:
        """Benchmark JSON serialization performance"""
        # Create test data with various edge cases
        test_data = []
        for i in range(100):
            data = {
                'id': i,
                'value': float('inf') if i % 10 == 0 else float(i),
                'nested': {
                    'inf_value': float('-inf') if i % 15 == 0 else float(i * 2),
                    'nan_value': float('nan') if i % 20 == 0 else float(i * 3),
                    'array': [float('inf'), float('nan'), i] if i % 25 == 0 else [i, i*2]
                }
            }
            test_data.append(data)
        
        times = []
        for _ in range(self.iterations // 10):  # Fewer iterations for heavier operation
            start = time.perf_counter()
            safe_json_dumps(test_data)
            end = time.perf_counter()
            times.append(end - start)
        
        return self._calculate_stats('json_serialization', times, len(test_data))
    
    def benchmark_product_creation(self) -> BenchmarkResult:
        """Benchmark StandardizedProduct creation with sanitization"""
        times = []
        for _ in range(self.iterations // 5):
            start = time.perf_counter()
            product = StandardizedProduct(
                source_url=f"https://test.com/product",
                category="test_category",
                name="Benchmark Product",
                provider_name="BenchmarkCorp",
                data_gb=float('inf'),
                calls=float('nan'),
                texts=float('-inf'),
                monthly_cost=float('inf'),
                raw_data={
                    'performance_test': True,
                    'inf_values': [float('inf'), float('-inf')],
                    'nan_values': [float('nan')] * 10
                }
            )
            # Force conversion to dict to include sanitization time
            product.to_json_safe_dict()
            end = time.perf_counter()
            times.append(end - start)
        
        return self._calculate_stats('product_creation', times, 1)
    
    def benchmark_large_dataset(self, size: int = 1000) -> BenchmarkResult:
        """Benchmark large dataset processing"""
        # Create large dataset
        products = []
        for i in range(size):
            product = StandardizedProduct(
                source_url=f"https://test.com/large_{i}",
                category=f"category_{i % 10}",
                name=f"Large Dataset Product {i}",
                provider_name=f"Provider {i % 5}",
                data_gb=float('inf') if i % 10 == 0 else float(i),
                calls=float('nan') if i % 15 == 0 else float(i * 10),
                raw_data={'index': i, 'inf_test': float('inf') if i % 20 == 0 else i}
            )
            products.append(product)
        
        times = []
        for _ in range(5):  # Only 5 iterations for large datasets
            start = time.perf_counter()
            
            # Convert all products to JSON-safe dicts
            safe_dicts = [p.to_json_safe_dict() for p in products]
            
            # Serialize to JSON
            json_output = safe_json_dumps(safe_dicts)
            
            end = time.perf_counter()
            times.append(end - start)
        
        return self._calculate_stats(f'large_dataset_{size}', times, size)
    
    def _calculate_stats(self, operation: str, times: List[float], 
                        operations_count: int) -> BenchmarkResult:
        """Calculate statistics from timing data"""
        total_time = sum(times)
        avg_time = statistics.mean(times)
        min_time = min(times)
        max_time = max(times)
        p95_time = statistics.quantiles(times, n=20)[18]  # 95th percentile
        p99_time = statistics.quantiles(times, n=100)[98]  # 99th percentile
        ops_per_second = (operations_count * len(times)) / total_time
        
        # Rough memory estimate (would need memory_profiler for accuracy)
        memory_usage_mb = 0.0  # Placeholder
        
        result = BenchmarkResult(
            operation=operation,
            total_time=total_time,
            avg_time=avg_time,
            min_time=min_time,
            max_time=max_time,
            p95_time=p95_time,
            p99_time=p99_time,
            operations_per_second=ops_per_second,
            memory_usage_mb=memory_usage_mb
        )
        
        self.results.append(result)
        return result
    
    def run_all_benchmarks(self) -> List[BenchmarkResult]:
        """Run all benchmarks and return results"""
        print("🚀 Starting JSON Safety Benchmarks...")
        
        print("1. Float conversion benchmark...")
        self.benchmark_float_conversion()
        
        print("2. JSON serialization benchmark...")
        self.benchmark_json_serialization()
        
        print("3. Product creation benchmark...")
        self.benchmark_product_creation()
        
        print("4. Large dataset benchmark (1K items)...")
        self.benchmark_large_dataset(1000)
        
        print("5. Large dataset benchmark (10K items)...")
        self.benchmark_large_dataset(10000)
        
        print("✅ All benchmarks completed!")
        return self.results
    
    def print_results(self):
        """Print benchmark results in a formatted table"""
        print("\n📊 Benchmark Results:")
        print("=" * 100)
        print(f"{'Operation':<25} {'Avg Time':<12} {'P95 Time':<12} {'P99 Time':<12} {'Ops/Sec':<12}")
        print("-" * 100)
        
        for result in self.results:
            print(f"{result.operation:<25} "
                  f"{result.avg_time*1000:.3f}ms    "
                  f"{result.p95_time*1000:.3f}ms    "
                  f"{result.p99_time*1000:.3f}ms    "
                  f"{result.operations_per_second:.1f}")
        
        print("=" * 100)

# Example usage
if __name__ == "__main__":
    benchmark = JsonSafetyBenchmark(iterations=1000)
    results = benchmark.run_all_benchmarks()
    benchmark.print_results()