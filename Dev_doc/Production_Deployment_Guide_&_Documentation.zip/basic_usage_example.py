"""
Basic usage example for JSON-Safe utilities in production
"""
from complete_json_safe_test_suite import (
    json_safe_float, safe_json_dumps, JsonSafeConfig,
    StandardizedProduct, advanced_mock_db
)
import math

# Example 1: Basic float conversion
unsafe_data = {
    "unlimited_data": float('inf'),
    "unknown_speed": float('nan'),
    "invalid_price": float('-inf'),
    "normal_value": 42.5
}

# Convert to JSON-safe
safe_data = {
    key: json_safe_float(value) if isinstance(value, float) else value
    for key, value in unsafe_data.items()
}

# Safe JSON serialization
json_output = safe_json_dumps(safe_data)
print(f"✅ Safe JSON: {json_output}")

# Example 2: Product creation with automatic sanitization
product = StandardizedProduct(
    source_url="https://example.com/unlimited-plan",
    category="mobile_plan",
    name="Unlimited Everything",
    provider_name="TechCorp",
    data_gb=float('inf'),  # Automatically converted
    monthly_cost=float('nan'),  # Automatically handled
    raw_data={
        "features": {
            "speed": float('inf'),
            "quality": float('nan')
        }
    }
)

# Product is automatically JSON-safe
product_json = safe_json_dumps(product.to_json_safe_dict())
print(f"✅ Product JSON: {product_json}")