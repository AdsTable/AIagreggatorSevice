#!/bin/bash
# Quick installation script for JSON-Safe Test Suite

# Install dependencies
pip install pytest pytest-asyncio fastapi httpx sqlmodel sqlalchemy

# Optional: Install with all extras
pip install "fastapi[all]" "sqlalchemy[asyncio]" uvicorn gunicorn

# Set environment variables
export JSON_SAFE_POSITIVE_INF=999999.0
export JSON_SAFE_NEGATIVE_INF=-999999.0
export JSON_SAFE_NAN_STRATEGY=null
export JSON_SAFE_LOG_CONVERSIONS=false

echo "✅ JSON-Safe Test Suite installed successfully!"