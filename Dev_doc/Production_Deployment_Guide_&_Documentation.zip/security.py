"""
Security hardening for JSON-safe operations
"""
import hashlib
import hmac
import time
from typing import Any, Dict, Optional
from functools import wraps

class SecurityConfig:
    """Security configuration"""
    MAX_JSON_SIZE = 10 * 1024 * 1024  # 10MB
    MAX_RECURSION_DEPTH = 100
    RATE_LIMIT_REQUESTS = 1000  # per minute
    ENABLE_CONTENT_VALIDATION = True
    SECRET_KEY = "your-secret-key-here"  # Should be from environment

class SecurityValidator:
    """Security validation for JSON data"""
    
    @staticmethod
    def validate_json_size(data: str) -> bool:
        """Validate JSON size doesn't exceed limits"""
        return len(data.encode('utf-8')) <= SecurityConfig.MAX_JSON_SIZE
    
    @staticmethod
    def validate_recursion_depth(obj: Any, current_depth: int = 0) -> bool:
        """Validate object doesn't exceed recursion depth"""
        if current_depth > SecurityConfig.MAX_RECURSION_DEPTH:
            return False
        
        if isinstance(obj, dict):
            return all(
                SecurityValidator.validate_recursion_depth(v, current_depth + 1)
                for v in obj.values()
            )
        elif isinstance(obj, list):
            return all(
                SecurityValidator.validate_recursion_depth(item, current_depth + 1)
                for item in obj
            )
        
        return True
    
    @staticmethod
    def sanitize_input(data: Any) -> Any:
        """Sanitize input data for security"""
        if isinstance(data, str):
            # Remove potential XSS vectors
            data = data.replace('<script>', '').replace('</script>', '')
            data = data.replace('javascript:', '')
        elif isinstance(data, dict):
            return {k: SecurityValidator.sanitize_input(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [SecurityValidator.sanitize_input(item) for item in data]
        
        return data

def rate_limit(max_requests: int = SecurityConfig.RATE_LIMIT_REQUESTS):
    """Rate limiting decorator"""
    request_counts = {}
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            client_id = kwargs.get('client_id', 'anonymous')
            current_time = int(time.time() / 60)  # Current minute
            
            if client_id not in request_counts:
                request_counts[client_id] = {}
            
            # Clean old entries
            request_counts[client_id] = {
                minute: count for minute, count in request_counts[client_id].items()
                if minute >= current_time - 1
            }
            
            # Check rate limit
            current_requests = request_counts[client_id].get(current_time, 0)
            if current_requests >= max_requests:
                raise ValueError(f"Rate limit exceeded for client {client_id}")
            
            # Increment counter
            request_counts[client_id][current_time] = current_requests + 1
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def secure_json_dumps(obj: Any, **kwargs) -> str:
    """Security-hardened JSON serialization"""
    # Validate recursion depth
    if not SecurityValidator.validate_recursion_depth(obj):
        raise ValueError("Object exceeds maximum recursion depth")
    
    # Sanitize input
    sanitized_obj = SecurityValidator.sanitize_input(obj)
    
    # Use safe JSON dumps
    from complete_json_safe_test_suite import safe_json_dumps
    result = safe_json_dumps(sanitized_obj, **kwargs)
    
    # Validate output size
    if not SecurityValidator.validate_json_size(result):
        raise ValueError("JSON output exceeds maximum size limit")
    
    return result