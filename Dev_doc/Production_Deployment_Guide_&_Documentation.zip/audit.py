"""
Audit logging for compliance and security monitoring
"""
import json
import hashlib
from datetime import datetime
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict

@dataclass
class AuditEvent:
    """Audit event structure"""
    timestamp: str
    event_type: str
    user_id: str
    action: str
    resource: str
    result: str  # 'success' or 'failure'
    details: Dict[str, Any]
    data_hash: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None

class AuditLogger:
    """Comprehensive audit logging"""
    
    def __init__(self, log_file: str = '/var/log/json-safe-audit.log'):
        self.log_file = log_file
    
    def log_event(self, event: AuditEvent):
        """Log an audit event"""
        event_dict = asdict(event)
        log_entry = json.dumps(event_dict, ensure_ascii=False)
        
        with open(self.log_file, 'a') as f:
            f.write(log_entry + '\n')
    
    def log_json_conversion(self, user_id: str, original_data: Any, 
                           converted_data: Any, success: bool = True):
        """Log JSON safety conversion events"""
        # Create data hash for integrity verification
        original_hash = hashlib.sha256(str(original_data).encode()).hexdigest()
        converted_hash = hashlib.sha256(str(converted_data).encode()).hexdigest()
        
        event = AuditEvent(
            timestamp=datetime.utcnow().isoformat(),
            event_type='json_conversion',
            user_id=user_id,
            action='convert_unsafe_values',
            resource='json_data',
            result='success' if success else 'failure',
            details={
                'original_hash': original_hash,
                'converted_hash': converted_hash,
                'conversion_applied': success
            }
        )
        
        self.log_event(event)
    
    def log_api_access(self, user_id: str, endpoint: str, method: str,
                      status_code: int, ip_address: str = None):
        """Log API access events"""
        event = AuditEvent(
            timestamp=datetime.utcnow().isoformat(),
            event_type='api_access',
            user_id=user_id,
            action=f'{method}_{endpoint}',
            resource=endpoint,
            result='success' if 200 <= status_code < 400 else 'failure',
            details={
                'http_method': method,
                'status_code': status_code
            },
            ip_address=ip_address
        )
        
        self.log_event(event)

# Global audit logger
audit_logger = AuditLogger()