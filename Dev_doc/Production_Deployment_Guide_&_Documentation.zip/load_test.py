"""
Load testing for JSON-safe API endpoints using Locust
"""
from locust import HttpUser, task, between
import json
import random

class JsonSafeApiUser(HttpUser):
    """Load test user for JSON-safe API"""
    
    wait_time = between(1, 3)  # Wait 1-3 seconds between requests
    
    def on_start(self):
        """Setup test data"""
        self.test_products = [
            {
                "source_url": f"https://test.com/product_{i}",
                "category": random.choice(["mobile_plan", "electricity_plan", "internet_plan"]),
                "name": f"Load Test Product {i}",
                "provider_name": f"Provider {i % 5}",
                "data_gb": float('inf') if i % 10 == 0 else random.randint(1, 100),
                "monthly_cost": float('nan') if i % 15 == 0 else random.uniform(10, 100)
            }
            for i in range(100)
        ]
    
    @task(3)
    def search_products(self):
        """Test product search endpoint"""
        params = {
            "category": random.choice(["mobile_plan", "electricity_plan"]),
            "available_only": random.choice([True, False])
        }
        
        with self.client.get("/search", params=params, catch_response=True) as response:
            if response.status_code == 200:
                data = response.json()
                if 'inf' in response.text.lower() or 'nan' in response.text.lower():
                    response.failure("Response contains unsafe JSON values")
                else:
                    response.success()
            else:
                response.failure(f"Unexpected status code: {response.status_code}")
    
    @task(2)
    def health_check(self):
        """Test health endpoint"""
        with self.client.get("/health", catch_response=True) as response:
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "healthy":
                    response.success()
                else:
                    response.failure("Health check failed")
            else:
                response.failure(f"Health check returned {response.status_code}")
    
    @task(1)
    def stress_test_edge_cases(self):
        """Test API with edge case data"""
        edge_case_data = {
            "products": [
                {
                    "name": "Edge Case Product",
                    "data_gb": float('inf'),
                    "speed": float('-inf'),
                    "quality": float('nan'),
                    "nested": {
                        "values": [float('inf'), float('nan')] * 10
                    }
                }
            ]
        }
        
        # This would be a POST endpoint that accepts product data
        with self.client.post("/validate", 
                             json=edge_case_data, 
                             catch_response=True) as response:
            if response.status_code in [200, 400]:  # 400 might be expected for invalid data
                if 'inf' not in response.text.lower() and 'nan' not in response.text.lower():
                    response.success()
                else:
                    response.failure("Response contains unsafe JSON values")
            else:
                response.failure(f"Unexpected status code: {response.status_code}")

# Command to run load test:
# locust -f load_test.py --host=http://localhost:8000 --users=50 --spawn-rate=5