from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
import json
from typing import Callable

class JsonSafeMiddleware:
    """Middleware для автоматической JSON санитизации всех API ответов"""
    
    def __init__(self, app: FastAPI):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        async def send_wrapper(message):
            if message["type"] == "http.response.body":
                # Перехватываем тело ответа
                body = message.get("body", b"")
                if body:
                    try:
                        # Парсим JSON
                        data = json.loads(body.decode())
                        # Санитизируем
                        safe_data = json_safe_dict(data) if isinstance(data, dict) else json_safe_list(data)
                        # Пересериализуем
                        safe_body = safe_json_dumps(safe_data).encode()
                        message["body"] = safe_body
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        # Если не JSON, оставляем как есть
                        pass
            
            await send(message)
        
        await self.app(scope, receive, send_wrapper)

# Использование:
# app = FastAPI()
# app.add_middleware(JsonSafeMiddleware)