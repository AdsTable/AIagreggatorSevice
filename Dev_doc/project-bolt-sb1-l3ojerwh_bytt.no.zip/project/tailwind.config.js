/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        blue: {
          50: '#f0f7ff',
          100: '#e0efff',
          200: '#c7e0ff',
          300: '#a3caff',
          400: '#77a9ff',
          500: '#4d84fb',
          600: '#0066CC', // Primary blue
          700: '#0057b3',
          800: '#004494',
          900: '#003c7a',
        },
        teal: {
          50: '#eefbfa',
          100: '#d4f5f2',
          200: '#adeae6',
          300: '#7ad8d2',
          400: '#43bdb5',
          500: '#00A693', // Secondary teal
          600: '#00897a',
          700: '#006e64',
          800: '#005751',
          900: '#004845',
        },
        orange: {
          500: '#FF9500', // Accent orange
        },
        green: {
          500: '#34C759', // Success green
        },
        yellow: {
          500: '#FFCC00', // Warning yellow
        },
        red: {
          500: '#FF3B30', // Error red
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.5s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};