import { Category, Condition } from '../types';

export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('no-NO', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(date);
};

export const getCategoryLabel = (category: Category): string => {
  const labels: Record<Category, string> = {
    electronics: 'Elektronikk',
    furniture: 'Møbler',
    clothing: 'Klær',
    books: 'Bøker',
    sports: 'Sport',
    toys: 'Leker',
    tools: 'Verktøy',
    other: 'Annet',
  };
  
  return labels[category] || category;
};

export const getConditionLabel = (condition: Condition): string => {
  const labels: Record<Condition, string> = {
    'new': 'Ny',
    'like-new': 'Som ny',
    'good': 'God',
    'fair': 'Brukbar',
    'poor': 'Slitt',
  };
  
  return labels[condition] || condition;
};

export const getConditionColor = (condition: Condition): string => {
  const colors: Record<Condition, string> = {
    'new': 'bg-green-100 text-green-800',
    'like-new': 'bg-blue-100 text-blue-800',
    'good': 'bg-yellow-100 text-yellow-800',
    'fair': 'bg-orange-100 text-orange-800',
    'poor': 'bg-red-100 text-red-800',
  };
  
  return colors[condition] || '';
};