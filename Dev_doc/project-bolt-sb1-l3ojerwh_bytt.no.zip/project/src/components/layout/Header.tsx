import React, { useState, useEffect } from 'react';
import { Menu, X, Heart, Bell, Search, User, PlusCircle } from 'lucide-react';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const headerClass = isScrolled
    ? 'bg-white shadow-md'
    : 'bg-transparent';

  const textColorClass = isScrolled
    ? 'text-gray-900'
    : 'text-white';

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${headerClass}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className={`text-2xl font-bold ${textColorClass}`}>
              bytt.no
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className={`${textColorClass} hover:text-blue-500 transition-colors`}>
              Utforsk
            </a>
            <a href="#" className={`${textColorClass} hover:text-blue-500 transition-colors`}>
              Kategorier
            </a>
            <a href="#" className={`${textColorClass} hover:text-blue-500 transition-colors`}>
              Hvordan det fungerer
            </a>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button 
              className={`p-2 rounded-full hover:bg-gray-100/10 ${textColorClass}`}
              aria-label="Søk"
            >
              <Search className="h-5 w-5" />
            </button>
            <button 
              className={`p-2 rounded-full hover:bg-gray-100/10 ${textColorClass}`}
              aria-label="Favoritter"
            >
              <Heart className="h-5 w-5" />
            </button>
            <Button 
              variant="primary" 
              icon={<PlusCircle className="h-5 w-5" />}
            >
              Legg ut annonse
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMobileMenu}
              className={`p-2 rounded-full ${textColorClass}`}
              aria-label={isMobileMenuOpen ? 'Lukk meny' : 'Åpne meny'}
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg overflow-hidden transition-all duration-300 ease-in-out">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex flex-col space-y-4">
              <a href="#" className="text-gray-900 hover:text-blue-500 py-2 transition-colors">
                Utforsk
              </a>
              <a href="#" className="text-gray-900 hover:text-blue-500 py-2 transition-colors">
                Kategorier
              </a>
              <a href="#" className="text-gray-900 hover:text-blue-500 py-2 transition-colors">
                Hvordan det fungerer
              </a>
              <div className="pt-2 border-t border-gray-100">
                <Button 
                  variant="primary" 
                  fullWidth 
                  icon={<PlusCircle className="h-5 w-5" />}
                >
                  Legg ut annonse
                </Button>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;