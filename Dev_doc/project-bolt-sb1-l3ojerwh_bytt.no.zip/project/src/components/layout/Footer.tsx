import React from 'react';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">bytt.no</h3>
            <p className="text-gray-600 mb-4">
              Norges største og enkleste bytteplattform - bytt, ikke kast.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-pink-600 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-blue-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Kategorier</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Elektronikk</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Møbler</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Klær</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Bøker</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Sport</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Informasjon</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Om oss</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Hvordan det fungerer</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Vanlige spørsmål</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Kontakt oss</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-900 mb-4">Juridisk</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Personvernerklæring</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Brukervilkår</a></li>
              <li><a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">Cookies</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              © 2025 bytt.no. Alle rettigheter reservert.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-500 hover:text-gray-700 text-sm transition-colors">
                Personvern
              </a>
              <a href="#" className="text-gray-500 hover:text-gray-700 text-sm transition-colors">
                Vilkår
              </a>
              <a href="#" className="text-gray-500 hover:text-gray-700 text-sm transition-colors">
                Cookies
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;