import React from 'react';
import { Listing } from '../../types';
import ListingCard from './ListingCard';

interface ListingGridProps {
  listings: Listing[];
  favorites?: string[];
  onToggleFavorite?: (id: string) => void;
}

const ListingGrid: React.FC<ListingGridProps> = ({ 
  listings, 
  favorites = [], 
  onToggleFavorite 
}) => {
  if (listings.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-gray-500">Ingen annonser funnet.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {listings.map((listing) => (
        <ListingCard
          key={listing.id}
          listing={listing}
          isFavorite={favorites.includes(listing.id)}
          onFavorite={onToggleFavorite}
        />
      ))}
    </div>
  );
};

export default ListingGrid;