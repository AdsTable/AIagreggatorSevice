import React from 'react';
import { Listing } from '../../types';
import { formatDate, getConditionLabel, getConditionColor } from '../../utils/helpers';
import { Heart, MapPin } from 'lucide-react';

interface ListingCardProps {
  listing: Listing;
  onFavorite?: (id: string) => void;
  isFavorite?: boolean;
}

const ListingCard: React.FC<ListingCardProps> = ({ 
  listing, 
  onFavorite, 
  isFavorite = false 
}) => {
  const {
    id,
    title,
    description,
    imageUrl,
    location,
    condition,
    createdAt,
  } = listing;

  const truncateText = (text: string, maxLength: number) => {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  return (
    <div className="group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-200">
      <div className="relative h-48 overflow-hidden">
        <img
          src={imageUrl}
          alt={title}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
        />
        <button
          onClick={() => onFavorite && onFavorite(id)}
          className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-sm hover:bg-white transition-colors"
        >
          <Heart 
            className={`h-5 w-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} 
          />
        </button>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg text-gray-900 group-hover:text-blue-600 transition-colors">
            {title}
          </h3>
          <span className={`text-xs px-2 py-1 rounded-full ${getConditionColor(condition)}`}>
            {getConditionLabel(condition)}
          </span>
        </div>
        <p className="text-gray-600 text-sm mb-3">
          {truncateText(description, 80)}
        </p>
        <div className="flex items-center text-gray-500 text-sm">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{location}</span>
        </div>
        <div className="mt-3 text-xs text-gray-400">
          {formatDate(createdAt)}
        </div>
      </div>
    </div>
  );
};

export default ListingCard;