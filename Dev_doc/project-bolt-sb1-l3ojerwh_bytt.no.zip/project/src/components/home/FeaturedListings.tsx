import React from 'react';
import { Listing } from '../../types';
import ListingGrid from '../listings/ListingGrid';
import { ArrowRight } from 'lucide-react';

interface FeaturedListingsProps {
  listings: Listing[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
}

const FeaturedListings: React.FC<FeaturedListingsProps> = ({ 
  listings, 
  favorites, 
  onToggleFavorite 
}) => {
  const featuredListings = listings.filter(listing => listing.isFeatured);
  
  return (
    <div className="py-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Utvalgte annonser</h2>
          <a 
            href="#" 
            className="text-blue-600 hover:text-blue-800 flex items-center text-sm font-medium transition-colors"
          >
            Se alle annonser
            <ArrowRight className="ml-1 h-4 w-4" />
          </a>
        </div>
        
        <ListingGrid 
          listings={featuredListings} 
          favorites={favorites}
          onToggleFavorite={onToggleFavorite}
        />
      </div>
    </div>
  );
};

export default FeaturedListings;