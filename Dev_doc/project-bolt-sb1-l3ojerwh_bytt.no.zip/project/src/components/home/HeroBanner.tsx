import React from 'react';
import SearchBar from '../ui/SearchBar';
import Button from '../ui/Button';
import { ArrowRight } from 'lucide-react';

interface HeroBannerProps {
  onSearch: (query: string) => void;
}

const HeroBanner: React.FC<HeroBannerProps> = ({ onSearch }) => {
  return (
    <div className="relative bg-gradient-to-br from-blue-600 to-blue-800 text-white">
      <div className="absolute inset-0 bg-blue-900 opacity-10 pattern-dots"></div>
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Bytt, ikke kast. Gi tingene dine nytt liv.
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100">
            Den enkleste måten å bytte ting du ikke trenger med ting du ønsker deg.
          </p>
          
          <div className="mb-8">
            <SearchBar onSearch={onSearch} />
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              variant="secondary" 
              size="lg"
            >
              Utforsk annonser
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
              icon={<ArrowRight className="h-5 w-5" />}
            >
              Legg ut annonse
            </Button>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
    </div>
  );
};

export default HeroBanner;