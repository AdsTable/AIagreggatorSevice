import React from 'react';
import { Category } from '../../types';
import CategoryPill from '../ui/CategoryPill';

interface CategorySectionProps {
  selectedCategory: Category | null;
  onSelectCategory: (category: Category | null) => void;
}

const CategorySection: React.FC<CategorySectionProps> = ({ 
  selectedCategory, 
  onSelectCategory 
}) => {
  const categories: Category[] = [
    'electronics',
    'furniture',
    'clothing',
    'books',
    'sports',
    'toys',
    'tools',
    'other',
  ];

  return (
    <div className="py-6">
      <div className="container mx-auto px-4">
        <h2 className="text-xl font-semibold mb-4">Kategorier</h2>
        <div className="flex flex-wrap gap-3">
          <CategoryPill
            category="other"
            isActive={selectedCategory === null}
            onClick={() => onSelectCategory(null)}
          />
          {categories.map((category) => (
            <CategoryPill
              key={category}
              category={category}
              isActive={selectedCategory === category}
              onClick={() => onSelectCategory(category)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategorySection;