import React from 'react';
import { Category } from '../../types';
import { getCategoryLabel } from '../../utils/helpers';
import { categoryIcons } from '../../data/mockData';

interface CategoryPillProps {
  category: Category;
  onClick?: () => void;
  isActive?: boolean;
}

const CategoryPill: React.FC<CategoryPillProps> = ({ 
  category, 
  onClick, 
  isActive = false 
}) => {
  const baseStyles = 'inline-flex items-center rounded-full py-1.5 px-3 text-sm font-medium transition-all duration-200 cursor-pointer';
  const activeStyles = isActive 
    ? 'bg-blue-100 text-blue-800 hover:bg-blue-200' 
    : 'bg-gray-100 text-gray-700 hover:bg-gray-200';
  
  return (
    <div 
      className={`${baseStyles} ${activeStyles}`}
      onClick={onClick}
    >
      <span className="mr-1.5">{categoryIcons[category]}</span>
      {getCategoryLabel(category)}
    </div>
  );
};

export default CategoryPill;