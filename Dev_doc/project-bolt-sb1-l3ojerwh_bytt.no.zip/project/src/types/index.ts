export interface Listing {
  id: string;
  title: string;
  description: string;
  category: Category;
  condition: Condition;
  location: string;
  imageUrl: string;
  createdAt: Date;
  userId: string;
  isFeatured: boolean;
}

export type Category = 
  | 'electronics'
  | 'furniture'
  | 'clothing'
  | 'books'
  | 'sports'
  | 'toys'
  | 'tools'
  | 'other';

export type Condition = 
  | 'new'
  | 'like-new'
  | 'good'
  | 'fair'
  | 'poor';