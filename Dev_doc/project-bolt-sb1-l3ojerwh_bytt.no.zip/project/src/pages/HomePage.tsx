import React, { useState } from 'react';
import HeroBanner from '../components/home/HeroBanner';
import CategorySection from '../components/home/CategorySection';
import FeaturedListings from '../components/home/FeaturedListings';
import { mockListings } from '../data/mockData';
import { Category } from '../types';

const HomePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Here you would typically filter listings or navigate to search results
    console.log('Searching for:', query);
  };

  const handleCategorySelect = (category: Category | null) => {
    setSelectedCategory(category);
    // Here you would typically filter listings by category
    console.log('Selected category:', category);
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => {
      if (prev.includes(id)) {
        return prev.filter(itemId => itemId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  // Filter listings by selected category if any
  const filteredListings = selectedCategory 
    ? mockListings.filter(listing => listing.category === selectedCategory)
    : mockListings;

  return (
    <div className="pt-16 md:pt-20"> {/* Add padding to account for fixed header */}
      <HeroBanner onSearch={handleSearch} />
      <CategorySection 
        selectedCategory={selectedCategory} 
        onSelectCategory={handleCategorySelect} 
      />
      <FeaturedListings 
        listings={filteredListings}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
      />

      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Hvordan fungerer bytt.no?
            </h2>
            <p className="text-lg text-gray-600 mb-10">
              Tre enkle steg for å gi tingene dine nytt liv
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-2">Legg ut annonse</h3>
                <p className="text-gray-600">
                  Ta noen bilder, beskriv gjenstanden og legg den ut på bytt.no helt gratis.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-2">Motta henvendelser</h3>
                <p className="text-gray-600">
                  Interesserte vil kontakte deg for å diskutere byttehandel eller avtale møte.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-2">Gjennomfør byttet</h3>
                <p className="text-gray-600">
                  Møt opp, utveksle gjenstander og gjør begge parter fornøyde.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;