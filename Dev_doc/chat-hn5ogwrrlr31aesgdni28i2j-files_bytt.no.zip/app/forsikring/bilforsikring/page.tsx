import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ComparisonTable } from "@/components/comparison-table"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Car, Shield, TrendingDown, Clock, Star, CheckCircle } from "lucide-react"

const carInsuranceProviders = [
  {
    name: "Gjensidige",
    rating: 4.2,
    reviews: 12458,
    basicPrice: "1,250",
    comprehensivePrice: "2,890",
    features: ["Bonus for skadefrihet", "Gratis båttrailer", "Europeisk dekning", "Teknisk hjelp"]
  },
  {
    name: "If Forsikring", 
    rating: 4.1,
    reviews: 9876,
    basicPrice: "1,180",
    comprehensivePrice: "2,750",
    features: ["Billig ungdomsrabatt", "Veteranbildekning", "Rask skadebehandling", "24/7 kundeservice"]
  },
  {
    name: "Fremtind",
    rating: 4.3,
    reviews: 8234,
    basicPrice: "1,320",
    comprehensivePrice: "3,100",
    features: ["Lokale avdelinger", "Personlig rådgiver", "Miljøvennlig bonus", "Rask utbetaling"]
  }
]

export default function CarInsurancePage() {
  console.log("Car insurance page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-blue-50/30 to-green-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center">
                  <Car className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Bilforsikring sammenligning
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn den billigste bilforsikringen med best dekning. Sammenlign priser 
                på ansvar, delkasko og kasko fra alle norske forsikringsselskaper.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Beregn min pris
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få 3 tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Facts */}
        <section className="py-12 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <TrendingDown className="h-8 w-8 text-accent mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Spar 2,400 kr/år</h3>
                  <p className="text-sm text-muted-foreground">
                    Gjennomsnittlig besparelse
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Clock className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">2 min sammenligning</h3>
                  <p className="text-sm text-muted-foreground">
                    Raskt og enkelt
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Shield className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">15 selskaper</h3>
                  <p className="text-sm text-muted-foreground">
                    Alle store aktører
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Star className="h-8 w-8 text-yellow-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Ekte kundeomtaler</h3>
                  <p className="text-sm text-muted-foreground">
                    Fra reelle kunder
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Insurance Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Typer bilforsikring
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card>
                <CardHeader>
                  <CardTitle>Ansvarsforsikring</CardTitle>
                  <CardDescription>Lovpålagt minimum</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Personskader på andre
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Tingskader på andre
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Rettshjelp
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Delkasko</CardTitle>
                  <CardDescription>Utvidet dekning</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Alt i ansvar
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Tyveri og innbrudd
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Brann og naturskader
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Hærverk
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Kasko</CardTitle>
                  <CardDescription>Fullstendig beskyttelse</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Alt i delkasko
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Kollisjonsskader
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Egne kjørefeil
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Utrykning og bergning
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Comparison Table */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign bilforsikringer
              </h2>
              <p className="text-lg text-muted-foreground">
                Oppdaterte priser og kundeanmeldelser
              </p>
            </div>
            
            <div className="space-y-6">
              {carInsuranceProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 0 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Billigst
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Få tilbud
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">ANSVAR</h4>
                        <div className="text-2xl font-bold text-primary">{provider.basicPrice} kr</div>
                        <div className="text-sm text-muted-foreground">per år</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">KASKO</h4>
                        <div className="text-xl font-semibold">{provider.comprehensivePrice} kr</div>
                        <div className="text-sm text-muted-foreground">per år</div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle forsikringsselskaper
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}