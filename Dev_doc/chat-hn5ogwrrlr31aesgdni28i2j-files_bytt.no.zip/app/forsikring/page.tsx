import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ComparisonTable } from "@/components/comparison-table"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Car, Home, Plane, ArrowRight, Star, TrendingDown } from "lucide-react"

const insuranceTypes = [
  {
    id: "bilforsikring",
    title: "Bilforsikring",
    description: "Sammenlign priser på bilforsikring fra alle selskaper",
    icon: Car,
    avgSaving: "2,400 kr/år",
    providers: 12,
    startPrice: "1,250 kr/år"
  },
  {
    id: "husforsikring", 
    title: "Husforsikring",
    description: "Finn beste husforsikring for din bolig",
    icon: Home,
    avgSaving: "1,800 kr/år",
    providers: 15,
    startPrice: "3,200 kr/år"
  },
  {
    id: "reiseforsikring",
    title: "Reiseforsikring", 
    description: "Sammenlign reiseforsikringer for trygg ferie",
    icon: Plane,
    avgSaving: "800 kr/år",
    providers: 10,
    startPrice: "450 kr/år"
  }
]

const mockProviders = [
  {
    name: "Gjensidige",
    rating: 4.2,
    reviews: 12458,
    carInsurance: "1,250",
    homeInsurance: "3,200", 
    travelInsurance: "450",
    features: ["Skadeoppgjør 24/7", "Bonus for skadefrihet", "Rabatt ved flere forsikringer"]
  },
  {
    name: "If Forsikring",
    rating: 4.1,
    reviews: 9876,
    carInsurance: "1,180",
    homeInsurance: "3,100",
    travelInsurance: "420",
    features: ["Rask saksbehandling", "Godt kundeservice", "Digitale tjenester"]
  },
  {
    name: "Fremtind",
    rating: 4.3,
    reviews: 8234,
    carInsurance: "1,320",
    homeInsurance: "3,350",
    travelInsurance: "480",
    features: ["Lokale avdelinger", "Personlig rådgiver", "Konkurransedyktige priser"]
  }
]

export default function InsurancePage() {
  console.log("Insurance page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-blue-50/30 to-green-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign forsikringer
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn de beste forsikringene med vårt enkle sammenligningstool. 
                Sammenlign priser og vilkår fra Norges ledende forsikringsselskaper.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Test dine forsikringer
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få 3 tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Insurance Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Velg type forsikring
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {insuranceTypes.map((type) => {
                const IconComponent = type.icon
                
                return (
                  <Card key={type.id} className="hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                          <IconComponent className="h-6 w-6 text-primary" />
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                      
                      <CardTitle className="text-xl">{type.title}</CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center text-sm">
                          <TrendingDown className="h-4 w-4 text-accent mr-2" />
                          <span className="text-muted-foreground">Spar i snitt:</span>
                          <span className="font-semibold text-accent ml-1">{type.avgSaving}</span>
                        </div>
                        
                        <div className="text-sm text-muted-foreground">
                          Fra {type.startPrice} • {type.providers} selskaper
                        </div>
                        
                        <Button variant="outline" size="sm" className="w-full">
                          Sammenlign nå
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </section>

        {/* Comparison Table */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign forsikringsselskaper
              </h2>
              <p className="text-lg text-muted-foreground">
                Se priser og kundevurderinger fra ekte kunder
              </p>
            </div>
            
            <ComparisonTable 
              providers={mockProviders}
              category="forsikring"
            />
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-8">
                Hvorfor sammenligne forsikringer?
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingDown className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="font-semibold mb-2">Spar penger</h3>
                  <p className="text-sm text-muted-foreground">
                    Kunder sparer i snitt 2,400 kr årlig ved å bytte forsikring
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Star className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Best dekning</h3>
                  <p className="text-sm text-muted-foreground">
                    Sammenlign dekning og vilkår for å finne best forsikring
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-6 w-6 text-orange-600" />
                  </div>
                  <h3 className="font-semibold mb-2">Trygg bytting</h3>
                  <p className="text-sm text-muted-foreground">
                    Vi hjelper deg med hele prosessen - helt gratis
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}