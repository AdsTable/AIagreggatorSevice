import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Thermometer, Snowflake, Sun, Star, CheckCircle, Calculator, Leaf } from "lucide-react"

const heatPumpProviders = [
  {
    name: "Mitsubishi Electric",
    rating: 4.5,
    reviews: 3456,
    priceRange: "Fra 45,000 kr",
    efficiency: "A+++",
    warranty: "5 år",
    features: ["Inverter teknologi", "WiFi styring", "Støysvak drift", "Automatisk avrimming"]
  },
  {
    name: "Panasonic",
    rating: 4.4,
    reviews: 2789,
    priceRange: "Fra 38,000 kr",
    efficiency: "A++",
    warranty: "3 år",
    features: ["Eco-modus", "Dual split mulig", "Kompakt design", "R32 kjølemiddel"]
  },
  {
    name: "Daikin",
    rating: 4.3,
    reviews: 4123,
    priceRange: "Fra 42,000 kr",
    efficiency: "A+++",
    warranty: "4 år",
    features: ["Flash streamer", "Urania filter", "Intelligent eye", "3D luftstrøm"]
  }
]

const heatPumpTypes = [
  {
    title: "Luft-til-luft",
    description: "Mest populære og rimelige varmepumper",
    efficiency: "COP 3-5",
    installation: "15,000-25,000 kr",
    features: ["Rask installasjon", "Både varme og kjøling", "Lavest investering", "Enkelt vedlikehold"]
  },
  {
    title: "Luft-til-vann", 
    description: "Kobles til vannbåren varme",
    efficiency: "COP 2.5-4",
    installation: "25,000-40,000 kr",
    features: ["Varmer hele huset", "Kan gi varmtvann", "Integreres i eksisterende anlegg", "Høy komfort"]
  },
  {
    title: "Bergvarme",
    description: "Energi fra bakken - mest effektivt",
    efficiency: "COP 4-6",
    installation: "80,000-150,000 kr",
    features: ["Høyest effektivitet", "Stabil året rundt", "Grønest alternativ", "Lavest driftskostnad"]
  }
]

export default function HeatPumpPage() {
  console.log("Heat pump page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-orange-50/30 to-red-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center">
                  <Thermometer className="h-8 w-8 text-orange-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign varmepumper
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn den beste varmepumpen for ditt hjem. Sammenlign priser, effektivitet 
                og installatører for luft-luft, luft-vann og bergvarmepumper.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Beregn besparelse
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få 3 tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-12 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <Calculator className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Spar 15,000 kr/år</h3>
                  <p className="text-sm text-muted-foreground">
                    På oppvarmingskostnader
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Leaf className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Miljøvennlig</h3>
                  <p className="text-sm text-muted-foreground">
                    Reduserer CO2-utslipp
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Sun className="h-8 w-8 text-orange-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Både varme og kjøling</h3>
                  <p className="text-sm text-muted-foreground">
                    Året rundt komfort
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Star className="h-8 w-8 text-yellow-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Økt boligverdi</h3>
                  <p className="text-sm text-muted-foreground">
                    Investering som lønner seg
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Heat Pump Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Typer varmepumper
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {heatPumpTypes.map((type, index) => (
                <Card key={index} className={index === 0 ? "border-2 border-primary/20" : ""}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      {index === 0 && <Thermometer className="h-6 w-6 text-primary" />}
                      {index === 1 && <Snowflake className="h-6 w-6 text-blue-600" />}
                      {index === 2 && <Leaf className="h-6 w-6 text-green-600" />}
                      {type.title}
                    </CardTitle>
                    <CardDescription>{type.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="font-semibold">Effektivitet</div>
                          <div className="text-muted-foreground">{type.efficiency}</div>
                        </div>
                        <div>
                          <div className="font-semibold">Installasjon</div>
                          <div className="text-muted-foreground">{type.installation}</div>
                        </div>
                      </div>
                      
                      <ul className="space-y-2 text-sm">
                        {type.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-accent mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      
                      <Button variant="outline" size="sm" className="w-full">
                        Les mer
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Brand Comparison */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign merker og installatører
              </h2>
              <p className="text-lg text-muted-foreground">
                Kvalitet, pris og service fra ledende leverandører
              </p>
            </div>
            
            <div className="space-y-6">
              {heatPumpProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 0 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Høyeste rating
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Få tilbud
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PRIS</h4>
                        <div className="text-2xl font-bold text-primary">{provider.priceRange}</div>
                        <div className="text-sm text-muted-foreground">inkl. installasjon</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">EFFEKTIVITET</h4>
                        <div className="text-xl font-semibold">{provider.efficiency}</div>
                        <div className="text-sm text-muted-foreground">Energiklasse</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">GARANTI</h4>
                        <div className="text-xl font-semibold">{provider.warranty}</div>
                        <div className="text-sm text-muted-foreground">fullgaranti</div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">TEKNOLOGI</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle installatører og merker
              </Button>
            </div>
          </div>
        </section>

        {/* Calculator Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Beregn din besparelse
              </h2>
              
              <Card>
                <CardHeader>
                  <CardTitle>Varmepumpe kalkulator</CardTitle>
                  <CardDescription>
                    Se hvor mye du kan spare med varmepumpe
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg">
                    <div className="text-center">
                      <Calculator className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Interaktiv besparelseskalkulator vil vises her</p>
                      <p className="text-sm">Sammenlign oppvarmingskostnader før og etter varmepumpe</p>
                    </div>
                  </div>
                  
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-primary">350 kWh</div>
                        <div className="text-sm text-muted-foreground">Gjennomsnittlig besparelse/mnd</div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-green-600">15,000 kr</div>
                        <div className="text-sm text-muted-foreground">Årlig besparelse</div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-4 text-center">
                        <div className="text-2xl font-bold text-orange-600">3.2 år</div>
                        <div className="text-sm text-muted-foreground">Tilbakebetalingstid</div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}