import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ServiceCategories } from "@/components/service-categories"
import { TrustIndicators } from "@/components/trust-indicators"
import { Footer } from "@/components/footer"

export default function Home() {
  console.log("Home page rendering")
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <ServiceCategories />
        <TrustIndicators />
      </main>
      <Footer />
    </div>
  );
}
