"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { 
  User, 
  FileText, 
  MessageSquare, 
  Star,
  Calendar,
  Bell,
  Settings,
  Shield,
  Download
} from "lucide-react"

const mockUserData = {
  name: "Ola Nordmann",
  email: "ola.nordmann@email.no",
  phone: "12345678",
  totalSavings: 15600,
  activeQuotes: 3,
  reviews: 2
}

const mockQuotes = [
  {
    id: 1,
    category: "Forsikring",
    provider: "Gjensidige",
    status: "Pending",
    requestDate: "2025-06-03",
    expectedSaving: 2400
  },
  {
    id: 2,
    category: "Strøm", 
    provider: "Fortum",
    status: "Received",
    requestDate: "2025-06-01",
    expectedSaving: 1800
  },
  {
    id: 3,
    category: "Mobilabonnement",
    provider: "Talkmore", 
    status: "Accepted",
    requestDate: "2025-05-28",
    expectedSaving: 600
  }
]

const mockMessages = [
  {
    id: 1,
    from: "Gjensidige",
    subject: "Ditt forsikringstilbud er klart",
    date: "2025-06-04",
    read: false
  },
  {
    id: 2,
    from: "Bytt.no",
    subject: "Tips: Spar mer på strømregningen",
    date: "2025-06-02", 
    read: true
  }
]

const mockReviews = [
  {
    id: 1,
    company: "Telenor",
    rating: 4,
    comment: "God kundeservice og stabil dekning",
    date: "2025-05-15"
  },
  {
    id: 2,
    company: "Lyse Energi",
    rating: 5,
    comment: "Konkurransedyktige priser og enkelt å bytte",
    date: "2025-04-20"
  }
]

export default function MyPage() {
  const [activeTab, setActiveTab] = useState("overview")
  
  console.log("My page rendering for user:", mockUserData.name)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Min side</h1>
            <p className="text-lg text-muted-foreground">
              Velkommen tilbake, {mockUserData.name}
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Oversikt</TabsTrigger>
              <TabsTrigger value="quotes">Mine tilbud</TabsTrigger>
              <TabsTrigger value="messages">Meldinger</TabsTrigger>
              <TabsTrigger value="reviews">Mine omtaler</TabsTrigger>
              <TabsTrigger value="settings">Innstillinger</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Total besparelse</CardTitle>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-accent">
                      {mockUserData.totalSavings.toLocaleString()} kr
                    </div>
                    <p className="text-xs text-muted-foreground">Dette året</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Aktive tilbud</CardTitle>
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockUserData.activeQuotes}</div>
                    <p className="text-xs text-muted-foreground">Venter på svar</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Mine omtaler</CardTitle>
                    <Star className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockUserData.reviews}</div>
                    <p className="text-xs text-muted-foreground">Publiserte omtaler</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Siste aktivitet</CardTitle>
                    <CardDescription>Dine nyeste tilbud og meldinger</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockQuotes.slice(0, 3).map((quote) => (
                        <div key={quote.id} className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{quote.provider}</div>
                            <div className="text-sm text-muted-foreground">{quote.category}</div>
                          </div>
                          <Badge variant={quote.status === "Received" ? "default" : "secondary"}>
                            {quote.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Nye meldinger</CardTitle>
                    <CardDescription>Viktige oppdateringer fra leverandører</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockMessages.map((message) => (
                        <div key={message.id} className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className={`font-medium ${!message.read ? 'text-primary' : ''}`}>
                              {message.subject}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Fra {message.from} • {message.date}
                            </div>
                          </div>
                          {!message.read && (
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Quotes Tab */}
            <TabsContent value="quotes" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Mine tilbud</CardTitle>
                  <CardDescription>Oversikt over alle dine forespørsler og tilbud</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockQuotes.map((quote) => (
                      <div key={quote.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <div className="font-medium text-lg">{quote.provider}</div>
                          <div className="text-sm text-muted-foreground">
                            {quote.category} • Forespurt {quote.requestDate}
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={quote.status === "Received" ? "default" : "secondary"}>
                            {quote.status}
                          </Badge>
                          <div className="text-sm text-muted-foreground mt-1">
                            Estimert besparelse: {quote.expectedSaving} kr/år
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Se detaljer
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Messages Tab */}
            <TabsContent value="messages" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Mine meldinger</CardTitle>
                  <CardDescription>Kommunikasjon med leverandører og Bytt.no</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockMessages.map((message) => (
                      <div key={message.id} className="flex items-start justify-between p-4 border rounded-lg">
                        <div className="flex-1">
                          <div className={`font-medium ${!message.read ? 'text-primary' : ''}`}>
                            {message.subject}
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            Fra {message.from} • {message.date}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {!message.read && (
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                          )}
                          <Button variant="outline" size="sm">
                            Les
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reviews Tab */}
            <TabsContent value="reviews" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Mine omtaler</CardTitle>
                      <CardDescription>Dine publiserte omtaler av selskaper</CardDescription>
                    </div>
                    <Button>
                      <Star className="h-4 w-4 mr-2" />
                      Skriv omtale
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockReviews.map((review) => (
                      <div key={review.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="font-medium text-lg">{review.company}</div>
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${i < review.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{review.comment}</p>
                        <div className="text-xs text-muted-foreground">Publisert {review.date}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personlige opplysninger</CardTitle>
                  <CardDescription>Administrer dine kontoopplysninger</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Navn</Label>
                      <Input id="name" defaultValue={mockUserData.name} />
                    </div>
                    <div>
                      <Label htmlFor="email">E-post</Label>
                      <Input id="email" type="email" defaultValue={mockUserData.email} />
                    </div>
                    <div>
                      <Label htmlFor="phone">Telefon</Label>
                      <Input id="phone" defaultValue={mockUserData.phone} />
                    </div>
                  </div>
                  <Button>Lagre endringer</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Varslingsinnstillinger</CardTitle>
                  <CardDescription>Velg hvordan du vil motta varsler</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">E-postvarsler</div>
                        <div className="text-sm text-muted-foreground">Motta oppdateringer på e-post</div>
                      </div>
                      <Button variant="outline" size="sm">Konfigurer</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">SMS-varsler</div>
                        <div className="text-sm text-muted-foreground">Viktige oppdateringer på SMS</div>
                      </div>
                      <Button variant="outline" size="sm">Konfigurer</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}