"use client"

import { useState } from "react"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"
import { PartnerManagement } from "@/components/partner-management"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  BarChart3, 
  Users, 
  TrendingUp, 
  MousePointer, 
  Eye,
  Building2,
  Settings,
  Bell,
  Shield,
  Database,
  Plus,
  Search,
  Filter
} from "lucide-react"

// Mock data for analytics dashboard
const mockAnalyticsData = {
  totalVisits: 127543,
  totalClicks: 23891,
  totalLeads: 4567,
  revenue: 1250000,
  activePartners: 89,
  conversionRate: 18.7,
  monthlyGrowth: 12.4
}

const mockCategoryData = [
  { name: "Forsikring", visits: 45621, clicks: 8934, leads: 1756, conversion: 19.6, revenue: 456000 },
  { name: "Strøm", visits: 38912, clicks: 7234, leads: 1345, conversion: 18.6, revenue: 298000 },
  { name: "Mobilabonnement", visits: 23456, clicks: 4567, leads: 891, conversion: 19.5, revenue: 387000 },
  { name: "Bank & lån", visits: 19434, clicks: 3156, leads: 575, conversion: 16.2, revenue: 109000 }
]

const mockPartnerData = [
  { name: "Gjensidige", category: "Forsikring", clicks: 2341, leads: 456, revenue: 45600, conversionRate: 19.5 },
  { name: "Telenor", category: "Mobil", clicks: 1876, leads: 387, revenue: 38700, conversionRate: 20.6 },
  { name: "Fortum", category: "Strøm", clicks: 1654, leads: 298, revenue: 29800, conversionRate: 18.0 },
  { name: "DNB", category: "Bank", clicks: 1432, leads: 234, revenue: 23400, conversionRate: 16.3 }
]

// Enhanced partner data for PartnerManagement component
const mockEnhancedPartners = [
  {
    id: "1",
    name: "Gjensidige",
    category: "Forsikring",
    email: "partner@gjensidige.no",
    phone: "22334455",
    status: 'active' as const,
    clicks: 2341,
    leads: 456,
    revenue: 45600,
    conversionRate: 19.5,
    joinDate: "2024-01-15",
    lastLogin: "2025-06-03"
  },
  {
    id: "2", 
    name: "Telenor",
    category: "Mobil",
    email: "business@telenor.no",
    phone: "81000000",
    status: 'active' as const,
    clicks: 1876,
    leads: 387,
    revenue: 38700,
    conversionRate: 20.6,
    joinDate: "2024-02-01",
    lastLogin: "2025-06-04"
  },
  {
    id: "3",
    name: "Fortum",
    category: "Strøm", 
    email: "partner@fortum.no",
    phone: "02222200",
    status: 'active' as const,
    clicks: 1654,
    leads: 298,
    revenue: 29800,
    conversionRate: 18.0,
    joinDate: "2024-01-20",
    lastLogin: "2025-06-02"
  },
  {
    id: "4",
    name: "DNB",
    category: "Bank",
    email: "bedrift@dnb.no", 
    phone: "03000300",
    status: 'pending' as const,
    clicks: 1432,
    leads: 234,
    revenue: 23400,
    conversionRate: 16.3,
    joinDate: "2024-05-15",
    lastLogin: "2025-06-01"
  },
  {
    id: "5",
    name: "Telia Norge",
    category: "Mobil",
    email: "partner@telia.no",
    phone: "81080000", 
    status: 'suspended' as const,
    clicks: 987,
    leads: 156,
    revenue: 15600,
    conversionRate: 15.8,
    joinDate: "2024-03-10",
    lastLogin: "2025-05-28"
  }
]

export default function AdminPage() {
  console.log("Admin page rendering")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Bytt.no Admin</h1>
              <p className="text-sm text-muted-foreground">Administrasjonspanel</p>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Varsler (3)
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Innstillinger
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Oversikt</TabsTrigger>
            <TabsTrigger value="analytics">Statistikk</TabsTrigger>
            <TabsTrigger value="partners">Partnere</TabsTrigger>
            <TabsTrigger value="content">Innhold</TabsTrigger>
            <TabsTrigger value="settings">Innstillinger</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <AnalyticsDashboard 
              data={mockAnalyticsData}
              categoryData={mockCategoryData}
              partnerData={mockPartnerData}
              timeframe="Siste 30 dager"
            />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Detaljert statistikk</h2>
                <p className="text-muted-foreground">Omfattende analyse av brukeradferd og konvertering</p>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtrer
                </Button>
                <Button>
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generer rapport
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Trafikkanalyse</CardTitle>
                  <CardDescription>Detaljert brukeradferd over tid</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Interaktive grafer og diagrammer</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Konvertering funnel</CardTitle>
                  <CardDescription>Brukerreise gjennom siden</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Sidebesøk</span>
                      <span className="font-semibold">127,543</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Sammenligninger</span>
                      <span className="font-semibold">45,621</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Klikk til partnere</span>
                      <span className="font-semibold">23,891</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Leads generert</span>
                      <span className="font-semibold">4,567</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Partners Tab */}
          <TabsContent value="partners" className="space-y-6">
            <PartnerManagement 
              partners={mockEnhancedPartners}
              onAddPartner={() => console.log("Add partner clicked")}
              onEditPartner={(partner) => console.log("Edit partner:", partner.name)}
              onDeletePartner={(partnerId) => console.log("Delete partner:", partnerId)}
              onToggleStatus={(partnerId) => console.log("Toggle status:", partnerId)}
            />
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Innholdsstyring</h2>
                <p className="text-muted-foreground">Administrer sideinnhold, kategorier og sammenligningstabeller</p>
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nytt innhold
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Kategorier</CardTitle>
                  <CardDescription>Administrer tjenestekategorier</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Forsikring</span>
                      <Button variant="outline" size="sm">Rediger</Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Strøm</span>
                      <Button variant="outline" size="sm">Rediger</Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Mobilabonnement</span>
                      <Button variant="outline" size="sm">Rediger</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sammenligningstabeller</CardTitle>
                  <CardDescription>Oppdater priser og tilbud</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Forsikring priser</span>
                      <Button variant="outline" size="sm">Oppdater</Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Strømpriser</span>
                      <Button variant="outline" size="sm">Oppdater</Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Mobilpriser</span>
                      <Button variant="outline" size="sm">Oppdater</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Kundeomtaler</CardTitle>
                  <CardDescription>Moderer brukeromtaler</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Nye omtaler</span>
                      <Badge variant="destructive">23</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Ventende godkjenning</span>
                      <Badge variant="secondary">7</Badge>
                    </div>
                    <Button size="sm" className="w-full mt-4">
                      Administrer omtaler
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Systeminnstillinger</CardTitle>
                  <CardDescription>Konfigurer systemparametere</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="api-rate-limit">API rate limit</Label>
                    <Input id="api-rate-limit" defaultValue="1000" />
                  </div>
                  <div>
                    <Label htmlFor="cache-ttl">Cache TTL (sekunder)</Label>
                    <Input id="cache-ttl" defaultValue="3600" />
                  </div>
                  <div>
                    <Label htmlFor="max-partners">Maks partnere per kategori</Label>
                    <Input id="max-partners" defaultValue="50" />
                  </div>
                  <Button>Lagre innstillinger</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Brukeradministrasjon</CardTitle>
                  <CardDescription>Administrer systemtilganger</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Administrator</div>
                        <div className="text-sm text-muted-foreground">Full tilgang</div>
                      </div>
                      <Badge variant="default">3 brukere</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Editor</div>
                        <div className="text-sm text-muted-foreground">Innhold og statistikk</div>
                      </div>
                      <Badge variant="secondary">5 brukere</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Partner</div>
                        <div className="text-sm text-muted-foreground">Begrenset tilgang</div>
                      </div>
                      <Badge variant="outline">{mockPartnerData.length} brukere</Badge>
                    </div>
                    <Button size="sm" className="w-full">
                      Administrer brukere
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}