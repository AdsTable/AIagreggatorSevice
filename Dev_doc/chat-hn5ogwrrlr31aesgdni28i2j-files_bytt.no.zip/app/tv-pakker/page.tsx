import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tv, Star, CheckCircle, Play, Zap, Heart } from "lucide-react"

const tvProviders = [
  {
    name: "Viaplay",
    rating: 4.1,
    reviews: 15623,
    price: "349 kr/mnd",
    channels: "70+ kanaler",
    content: "Sport + Serier",
    features: ["Premier League", "Nordisk innhold", "Samtidig streaming på 4 enheter", "Offline nedlasting"]
  },
  {
    name: "TV 2 Play",
    rating: 4.2,
    reviews: 23456,
    price: "179 kr/mnd",
    channels: "50+ kanaler", 
    content: "Norsk + Internasjonal",
    features: ["TV 2 kanaler", "Dokumentarer", "Norske serier", "Sport events"]
  },
  {
    name: "Netflix",
    rating: 4.4,
    reviews: 45678,
    price: "149 kr/mnd",
    channels: "Kun streaming",
    content: "Serier + Filmer",
    features: ["Originalt innhold", "4K kvalitet", "Barnesikring", "Personlige profiler"]
  }
]

const channelPackages = [
  {
    title: "Grunnpakke",
    price: "299 kr/mnd",
    channels: 40,
    description: "NRK, TV 2, alle hovedkanaler",
    features: ["HD kvalitet", "7 dagers replay", "Mobil app inkludert"]
  },
  {
    title: "Stor pakke",
    price: "549 kr/mnd", 
    channels: 80,
    description: "Alt i grunnpakke + premiumkanaler",
    features: ["Sport kanaler", "Film kanaler", "Dokumentar kanaler", "Barnekanaler"]
  },
  {
    title: "Total pakke",
    price: "799 kr/mnd",
    channels: 120,
    description: "Alle tilgjengelige kanaler",
    features: ["Alle sportkanaler", "Premium film", "Internasjonale kanaler", "4K innhold"]
  }
]

export default function TvPackagesPage() {
  console.log("TV packages page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-red-50/30 to-purple-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center">
                  <Tv className="h-8 w-8 text-red-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign TV-pakker
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn den beste TV-pakken med dine favorittkanaler og serier. 
                Sammenlign streaming, kabel-TV og digitale pakker fra alle leverandører.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Finn min pakke
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Sammenlign priser
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* TV Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Typer TV-tjenester
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Play className="h-6 w-6 text-primary" />
                    <div>
                      <CardTitle>Streaming</CardTitle>
                      <CardDescription>On-demand innhold når du vil</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Se når du vil
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Alle enheter
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Originalt innhold
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Rimelig alternativ
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Tv className="h-6 w-6 text-green-600" />
                    <div>
                      <CardTitle>Kabel/Satelitt</CardTitle>
                      <CardDescription>Tradisjonell TV med mange kanaler</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Mange kanaler
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Live sport
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Nyheter og dokumentarer
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Familievennlig
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Zap className="h-6 w-6 text-orange-600" />
                    <div>
                      <CardTitle>Hybrid</CardTitle>
                      <CardDescription>Best av begge verdener</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Live TV + streaming
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Opptak funksjon
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Replay tjenester
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2" />
                      Mobil tilgang
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Channel Packages */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Populære kanalpakker
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {channelPackages.map((pkg, index) => (
                <Card key={index} className={index === 1 ? "border-2 border-primary/20 relative" : ""}>
                  {index === 1 && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">
                        Mest populær
                      </Badge>
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle>{pkg.title}</CardTitle>
                    <div className="text-3xl font-bold text-primary">{pkg.price}</div>
                    <CardDescription>
                      {pkg.channels} kanaler • {pkg.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm mb-6">
                      {pkg.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-accent mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button 
                      variant={index === 1 ? "default" : "outline"} 
                      className="w-full"
                    >
                      Velg pakke
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Streaming Services Comparison */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign streamingtjenester
              </h2>
              <p className="text-lg text-muted-foreground">
                Populære streaming-apper og deres innhold
              </p>
            </div>
            
            <div className="space-y-6">
              {tvProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 2 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Heart className="h-3 w-3 mr-1" />
                              Mest populær
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Start abonnement
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PRIS</h4>
                        <div className="text-2xl font-bold text-primary">{provider.price}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">KANALER</h4>
                        <div className="text-xl font-semibold">{provider.channels}</div>
                        <div className="text-sm text-muted-foreground">tilgjengelig</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">INNHOLD</h4>
                        <div className="text-xl font-semibold">{provider.content}</div>
                        <div className="text-sm text-muted-foreground">fokus</div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle TV-tilbud og streaming
              </Button>
            </div>
          </div>
        </section>

        {/* Popular Content */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Hva ser nordmenn på?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">Sport</div>
                  <p className="text-sm text-muted-foreground">
                    Fotball, håndball, vintersport
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">Nyheter</div>
                  <p className="text-sm text-muted-foreground">
                    NRK, TV 2, internasjonale nyheter
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">Drama/Serier</div>
                  <p className="text-sm text-muted-foreground">
                    Nordisk noir, internasjonale serier
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">Dokumentarer</div>
                  <p className="text-sm text-muted-foreground">
                    Natur, historie, true crime
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}