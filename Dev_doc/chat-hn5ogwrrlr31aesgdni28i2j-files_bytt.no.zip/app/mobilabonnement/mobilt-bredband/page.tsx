import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Wifi, Router, Signal, Star, CheckCircle, MapPin } from "lucide-react"

const mobileBroadbandProviders = [
  {
    name: "Telia",
    rating: 4.2,
    reviews: 8934,
    dataLimit: "Ubegrenset",
    price: "399 kr/mnd",
    speed: "Opp til 100 Mbps",
    network: "4G/5G",
    features: ["5G nettverk", "Ubegrenset data", "Ingen bindingstid", "Mobil hotspot"]
  },
  {
    name: "Telenor",
    rating: 4.1,
    reviews: 12456,
    dataLimit: "100 GB",
    price: "349 kr/mnd", 
    speed: "Opp til 80 Mbps",
    network: "4G",
    features: ["God dekning", "Familierabatt", "EU roaming", "Støtte for alle enheter"]
  },
  {
    name: "Ice",
    rating: 4.0,
    reviews: 6789,
    dataLimit: "Ubegrenset",
    price: "299 kr/mnd",
    speed: "Opp til 50 Mbps",
    network: "4G",
    features: ["Rimelig alternativ", "Enkel avtale", "Rask aktivering", "Kundeservice"]
  }
]

export default function MobileBroadbandPage() {
  console.log("Mobile broadband page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-blue-50/30 to-green-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center">
                  <Router className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Mobilt bredbånd
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Trådløst internett hvor som helst. Sammenlign mobile bredbåndsløsninger 
                med 4G og 5G for hjemmet eller på farten.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Sjekk dekning
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Sammenlign tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* When to Choose Mobile Broadband */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Når velge mobilt bredbånd?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <MapPin className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Landlige områder</h3>
                  <p className="text-sm text-muted-foreground">
                    Der fiber ikke er tilgjengelig
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Router className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Rask installasjon</h3>
                  <p className="text-sm text-muted-foreground">
                    Oppe og kjører med en gang
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Wifi className="h-8 w-8 text-orange-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Backup-løsning</h3>
                  <p className="text-sm text-muted-foreground">
                    Reserve hvis fiber svikter
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Signal className="h-8 w-8 text-purple-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Mobil arbeidsplass</h3>
                  <p className="text-sm text-muted-foreground">
                    For hjemmekontor og reiser
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Technology Comparison */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              4G vs 5G mobilt bredbånd
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Signal className="h-6 w-6 text-blue-600" />
                    <div>
                      <CardTitle>4G LTE</CardTitle>
                      <CardDescription>Etablert og pålitelig teknologi</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-xl font-bold text-blue-600">Opp til 100 Mbps</div>
                      <div className="text-sm text-muted-foreground">Nedlastingshastighet</div>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Utbredt dekning i hele Norge
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Stabil forbindelse
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Lavere priser
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Godt egnet for vanlig bruk
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Signal className="h-6 w-6 text-primary" />
                    <div>
                      <CardTitle>5G</CardTitle>
                      <CardDescription>Neste generasjon mobilt internett</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-xl font-bold text-primary">Opp til 1000 Mbps</div>
                      <div className="text-sm text-muted-foreground">Nedlastingshastighet</div>
                    </div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Ultrarask hastighet
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Lav latency for gaming
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Mange enheter samtidig
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Fremtidssikret teknologi
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Provider Comparison */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign mobilt bredbånd
              </h2>
              <p className="text-lg text-muted-foreground">
                Datamengde, hastighet og priser fra alle operatører
              </p>
            </div>
            
            <div className="space-y-6">
              {mobileBroadbandProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 0 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              5G tilgjengelig
                            </Badge>
                          )}
                          {index === 2 && (
                            <Badge className="bg-green-100 text-green-800">
                              Lavest pris
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Velg tilbud
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PRIS</h4>
                        <div className="text-2xl font-bold text-primary">{provider.price}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">DATA</h4>
                        <div className="text-xl font-semibold">{provider.dataLimit}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">HASTIGHET</h4>
                        <div className="text-xl font-semibold">{provider.speed}</div>
                        <div className="text-sm text-muted-foreground">nedlasting</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">NETTVERK</h4>
                        <div className="text-xl font-semibold">{provider.network}</div>
                        <div className="text-sm text-muted-foreground">teknologi</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="space-y-1">
                          {provider.features.slice(0, 2).map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle mobile bredbåndstilbud
              </Button>
            </div>
          </div>
        </section>

        {/* Coverage Map Section */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Sjekk dekning i ditt område
              </h2>
              
              <Card>
                <CardHeader>
                  <CardTitle>Dekningskart</CardTitle>
                  <CardDescription>
                    Se 4G og 5G dekning fra alle operatører
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-muted-foreground border-2 border-dashed border-gray-300 rounded-lg">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Interaktivt dekningskart vil vises her</p>
                      <p className="text-sm">Sammenlign dekning fra Telenor, Telia og Ice</p>
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-center">
                    <Button>
                      <MapPin className="h-4 w-4 mr-2" />
                      Sjekk din adresse
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Tips Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Tips for mobilt bredbånd
              </h2>
              
              <div className="space-y-4">
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-2">Sjekk dekning først</h3>
                    <p className="text-sm text-muted-foreground">
                      Hastigheten avhenger av signalstyrken der du skal bruke internett. 
                      Test dekning både innendørs og utendørs.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-2">Vurder dataforbruk</h3>
                    <p className="text-sm text-muted-foreground">
                      Streaming og gaming bruker mye data. Velg ubegrenset hvis du har høyt forbruk, 
                      eller overvåk bruken nøye.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-2">Plassering av utstyr</h3>
                    <p className="text-sm text-muted-foreground">
                      Plasser ruteren nær vindu og unngå tykke vegger for best signal. 
                      Ekstern antenne kan forbedre signalet.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}