import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Smartphone, Wifi, Users, Star, CheckCircle, ArrowRight } from "lucide-react"

const mobileProviders = [
  {
    name: "Talkmore",
    rating: 4.3,
    reviews: 15623,
    price: "149 kr/mnd",
    data: "20 GB",
    calls: "Ubegrenset",
    network: "Telenor",
    features: ["EU roaming inkludert", "5G inkludert", "Familierabatt tilgjengelig"]
  },
  {
    name: "Phonero", 
    rating: 4.2,
    reviews: 8934,
    price: "159 kr/mnd",
    data: "25 GB", 
    calls: "Ubegrenset",
    network: "Telia",
    features: ["Musikktjenester inkludert", "Ubegrenset sosiale medier", "Deling av data"]
  },
  {
    name: "Chess",
    rating: 4.1,
    reviews: 12456,
    price: "139 kr/mnd",
    data: "15 GB",
    calls: "Ubegrenset", 
    network: "Telia",
    features: ["Billigst i test", "Enkle vilkår", "Rask kundeservice"]
  }
]

export default function MobilePage() {
  console.log("Mobile/Phone subscription page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-green-50/30 to-blue-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center">
                  <Smartphone className="h-8 w-8 text-green-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign mobilabonnement
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn det billigste mobilabonnementet som passer dine behov. 
                Sammenlign priser, data og nettverk fra alle operatører.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Test ditt abonnement
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få 3 tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Mobile Plans Comparison */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Norges billigste mobilabonnement
              </h2>
              <p className="text-lg text-muted-foreground">
                Sammenlign 113 abonnement fra 12 operatører
              </p>
            </div>
            
            <div className="space-y-6">
              {mobileProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 0 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Best pris
                            </Badge>
                          )}
                          <Badge variant="outline">{provider.network} nett</Badge>
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Velg abonnement
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      {/* Price */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PRIS</h4>
                        <div className="text-2xl font-bold text-primary">{provider.price}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      {/* Data */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">DATA</h4>
                        <div className="text-xl font-semibold">{provider.data}</div>
                        <div className="text-sm text-muted-foreground">4G/5G</div>
                      </div>
                      
                      {/* Calls */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">SAMTALER</h4>
                        <div className="text-xl font-semibold">{provider.calls}</div>
                        <div className="text-sm text-muted-foreground">i Norge</div>
                      </div>
                      
                      {/* Network */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">NETTVERK</h4>
                        <div className="text-xl font-semibold">{provider.network}</div>
                        <div className="text-sm text-muted-foreground">dekning</div>
                      </div>
                      
                      {/* Features */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="space-y-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle 113 mobilabonnement
              </Button>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Velg type abonnement
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <Smartphone className="h-8 w-8 text-primary" />
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  <CardTitle>Privat mobilabonnement</CardTitle>
                  <CardDescription>For privatpersoner og familier</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Fra 139 kr/mnd • 113 abonnement
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Sammenlign
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <Wifi className="h-8 w-8 text-green-600" />
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  <CardTitle>Mobilt bredbånd</CardTitle>
                  <CardDescription>Internet på farten</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Fra 249 kr/mnd • 45 abonnement  
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Sammenlign
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <Users className="h-8 w-8 text-orange-600" />
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  <CardTitle>Bedriftsabonnement</CardTitle>
                  <CardDescription>For bedrifter og organisasjoner</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Fra 189 kr/mnd • 67 abonnement
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Sammenlign
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}