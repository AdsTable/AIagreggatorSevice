import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Wifi, Router, Smartphone, Star, CheckCircle, TrendingDown } from "lucide-react"

const broadbandProviders = [
  {
    name: "Telenor",
    rating: 4.2,
    reviews: 18234,
    speed: "1000/1000",
    price: "549 kr/mnd",
    installation: "Gratis",
    features: ["Fri installasjon", "WiFi 6 ruter inkludert", "24/7 support", "TV-pakker tilgjengelig"]
  },
  {
    name: "Telia",
    rating: 4.1,
    reviews: 15678,
    speed: "500/500", 
    price: "449 kr/mnd",
    installation: "199 kr",
    features: ["Stabil forbindelse", "Gratis WiFi-ruter", "Ingen bindingstid", "Mobil+fiber pakker"]
  },
  {
    name: "Altibox",
    rating: 4.4,
    reviews: 12456,
    speed: "600/600",
    price: "499 kr/mnd", 
    installation: "Gratis",
    features: ["Lokal leverandør", "Symmetrisk hastighet", "TV og streaming", "Personlig support"]
  }
]

export default function BroadbandPage() {
  console.log("Broadband page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-purple-50/30 to-blue-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center">
                  <Wifi className="h-8 w-8 text-purple-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign bredbånd
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn det raskeste og billigste bredbåndet for ditt hjem. Sammenlign 
                fiber, ADSL og trådløst bredbånd fra alle leverandører.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Sjekk tilgjengelighet
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Speed Comparison */}
        <section className="py-12 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-center mb-8">
              Hvilken hastighet trenger du?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">10-50 Mbps</div>
                  <h3 className="font-semibold mb-2">Lett bruk</h3>
                  <p className="text-sm text-muted-foreground">
                    E-post, nettlesing, sosiale medier
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">50-100 Mbps</div>
                  <h3 className="font-semibold mb-2">Normal bruk</h3>
                  <p className="text-sm text-muted-foreground">
                    Streaming HD, video-chat, nedlasting
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">100-500 Mbps</div>
                  <h3 className="font-semibold mb-2">Tungt bruk</h3>
                  <p className="text-sm text-muted-foreground">
                    4K streaming, gaming, flere enheter
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold mb-2">500+ Mbps</div>
                  <h3 className="font-semibold mb-2">Ekstrem bruk</h3>
                  <p className="text-sm text-muted-foreground">
                    Hjemmekontor, store filer, mange brukere
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Broadband Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Typer bredbånd
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Wifi className="h-6 w-6 text-primary" />
                    <div>
                      <CardTitle>Fiber</CardTitle>
                      <CardDescription>Raskest og mest stabil</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-primary">Opp til 1000 Mbps</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Symmetrisk hastighet
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Lav latency for gaming
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Stabil forbindelse
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Fremtidssikret teknologi
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Router className="h-6 w-6 text-orange-600" />
                    <div>
                      <CardTitle>ADSL/VDSL</CardTitle>
                      <CardDescription>Bredbånd via telefonlinje</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-orange-600">Opp til 100 Mbps</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Tilgjengelig de fleste steder
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Rimelig alternativ
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Enkel installasjon
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Smartphone className="h-6 w-6 text-green-600" />
                    <div>
                      <CardTitle>Trådløst</CardTitle>
                      <CardDescription>4G/5G bredbånd</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-green-600">Opp til 300 Mbps</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Ingen kabler nødvendig
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Rask installasjon
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-accent mr-2" />
                        Bra for landlige områder
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Comparison Table */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign bredbåndsleverandører
              </h2>
              <p className="text-lg text-muted-foreground">
                Oppdaterte priser og hastigheter
              </p>
            </div>
            
            <div className="space-y-6">
              {broadbandProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 2 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Høyest rating
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Sjekk tilgjengelighet
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">HASTIGHET</h4>
                        <div className="text-2xl font-bold text-primary">{provider.speed}</div>
                        <div className="text-sm text-muted-foreground">Mbps</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PRIS</h4>
                        <div className="text-xl font-semibold">{provider.price}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">INSTALLASJON</h4>
                        <div className="text-xl font-semibold">{provider.installation}</div>
                        <div className="text-sm text-muted-foreground">Engangsavgift</div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle bredbåndsleverandører
              </Button>
            </div>
          </div>
        </section>

        {/* Tips Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Tips for å velge bredbånd
              </h2>
              
              <div className="prose prose-lg mx-auto text-muted-foreground">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <TrendingDown className="h-5 w-5 text-accent mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <strong>Sjekk tilgjengelighet:</strong> Ikke alle teknologier er tilgjengelige overalt. Fiber gir best hastighet, men ADSL kan være eneste alternativ i noen områder.
                    </div>
                  </li>
                  <li className="flex items-start">
                    <TrendingDown className="h-5 w-5 text-accent mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <strong>Vurder ditt behov:</strong> Tenk på hvor mange som bruker internett samtidig og hvilke aktiviteter dere driver med.
                    </div>
                  </li>
                  <li className="flex items-start">
                    <TrendingDown className="h-5 w-5 text-accent mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <strong>Les det som står med liten skrift:</strong> Sjekk bindingstid, oppsettsavgift og eventuelle dataforbegrensninger.
                    </div>
                  </li>
                  <li className="flex items-start">
                    <TrendingDown className="h-5 w-5 text-accent mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <strong>Test hastigheten:</strong> Virkelig hastighet kan avvike fra markedsført hastighet, spesielt på ADSL.
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}