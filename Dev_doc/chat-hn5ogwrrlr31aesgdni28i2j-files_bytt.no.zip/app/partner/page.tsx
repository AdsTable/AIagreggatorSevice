"use client"

import { useState } from "react"
import { PartnerAnalytics } from "@/components/partner-analytics"

// Mock data for partner dashboard
const mockPartnerStats = {
  totalClicks: 2341,
  totalLeads: 456,
  conversionRate: 19.5,
  estimatedRevenue: 45600,
  lastMonth: {
    clicks: 2156,
    leads: 398,
    conversionRate: 18.4,
    revenue: 39800
  }
}

const mockCampaigns = [
  { name: "Bilforsikring Kampanje", clicks: 1234, leads: 267, conversionRate: 21.6, budget: 25000, spent: 18500, status: 'active' as const },
  { name: "Husforsikring Tilbud", clicks: 891, leads: 156, conversionRate: 17.5, budget: 15000, spent: 12800, status: 'active' as const },
  { name: "Reiseforsikring Sommer", clicks: 567, leads: 89, conversionRate: 15.7, budget: 10000, spent: 10000, status: 'completed' as const }
]

const mockTrafficSources = [
  { source: "Organisk søk", clicks: 945, leads: 185, percentage: 40.4 },
  { source: "Sammenligningstabeller", clicks: 703, leads: 142, percentage: 30.0 },
  { source: "Kategori-sider", clicks: 468, leads: 92, percentage: 20.2 },
  { source: "Direkte trafikk", clicks: 225, leads: 37, percentage: 9.4 }
]

export default function PartnerPage() {
  console.log("Partner dashboard rendering")

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="p-6">
        <PartnerAnalytics
          partnerName="Gjensidige Forsikring"
          category="Forsikring"
          stats={mockPartnerStats}
          campaigns={mockCampaigns}
          trafficSources={mockTrafficSources}
          timeframe="Siste 30 dager"
        />
      </div>
    </div>
  )
}