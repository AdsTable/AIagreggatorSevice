import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Zap, Clock, Calculator, AlertTriangle } from "lucide-react"

const spotPriceProviders = [
  {
    name: "Tibber",
    markup: "2.9 øre/kWh",
    monthlyFee: "39 kr",
    features: ["Smart home integrasjon", "Sanntids forbruksoversikt", "Grønn strøm", "Prisvarsel i app"],
    rating: 4.3
  },
  {
    name: "Fjordkraft", 
    markup: "1.9 øre/kWh",
    monthlyFee: "29 kr",
    features: ["Lavest påslag", "Enkel app", "Kundeservice", "Rabatt på elbil-lading"],
    rating: 4.1
  },
  {
    name: "Lyse Energi",
    markup: "2.5 øre/kWh",
    monthlyFee: "35 kr",
    features: ["Norsk vannkraft", "Miljøsertifisert", "Lokal produksjon", "Støtter fornybar energi"],
    rating: 4.2
  }
]

export default function SpotPricePage() {
  console.log("Spot price electricity page rendering")

  const currentSpotPrice = 67.8

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-yellow-50/30 to-green-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-8 w-8 text-yellow-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Spotpris strøm
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Følg strømprisene time for time og spar penger. Sammenlign spotpris-leverandører 
                og velg den med lavest påslag og beste tjenester.
              </p>
              
              <div className="bg-white rounded-lg p-6 shadow-lg max-w-md mx-auto mb-8">
                <div className="text-sm text-muted-foreground mb-2">Dagens gjennomsnittspris</div>
                <div className="text-3xl font-bold text-primary mb-2">{currentSpotPrice} øre/kWh</div>
                <div className="flex items-center justify-center text-sm">
                  <TrendingDown className="h-4 w-4 text-green-600 mr-1" />
                  <span className="text-green-600">-12% fra i går</span>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Sammenlign spotpris
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Se dagens priser
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* How Spot Price Works */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Slik fungerer spotpris
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Clock className="h-6 w-6 text-primary" />
                    <CardTitle>Time for time</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Strømprisen endres hver time basert på tilbud og etterspørsel i markedet. 
                    Du betaler den faktiske markedsprisen pluss leverandørens påslag.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Calculator className="h-6 w-6 text-green-600" />
                    <CardTitle>Lavere kostnad</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Over tid vil du normalt spare penger sammenlignet med fastprisavtaler, 
                    spesielt hvis du kan flytte forbruk til perioder med lave priser.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-6 w-6 text-orange-600" />
                    <CardTitle>Varierende priser</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Prisene kan variere mye, spesielt mellom sommer og vinter. 
                    Du må være forberedt på høye priser i perioder med lite fornybar energi.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Provider Comparison */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign spotpris-leverandører
              </h2>
              <p className="text-lg text-muted-foreground">
                Påslag og månedlige avgifter varierer mellom leverandørene
              </p>
            </div>
            
            <div className="space-y-6">
              {spotPriceProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 1 && (
                            <Badge className="bg-accent text-accent-foreground">
                              Lavest påslag
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="text-sm text-muted-foreground mt-1">
                          Rating: {provider.rating}/5
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Velg tilbud
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">PÅSLAG</h4>
                        <div className="text-2xl font-bold text-primary">{provider.markup}</div>
                        <div className="text-sm text-muted-foreground">+ spotpris + nettleie</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">MÅNEDSAVGIFT</h4>
                        <div className="text-xl font-semibold">{provider.monthlyFee}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">DAGENS TOTALPRIS</h4>
                        <div className="text-xl font-semibold">
                          {(currentSpotPrice + parseFloat(provider.markup.replace(' øre/kWh', ''))).toFixed(1)} øre
                        </div>
                        <div className="text-sm text-muted-foreground">per kWh (ekskl. nettleie)</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="space-y-1">
                          {provider.features.slice(0, 2).map((feature, featureIndex) => (
                            <div key={featureIndex} className="text-sm">{feature}</div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Price Chart Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Strømpriser i dag
              </h2>
              
              <Card>
                <CardHeader>
                  <CardTitle>Time-for-time priser</CardTitle>
                  <CardDescription>
                    Spotpriser for i dag (øre/kWh ekskl. mva og nettleie)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <Zap className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Interaktiv prisdiagram vil vises her</p>
                      <p className="text-sm">Viser strømpriser per time for alle prisområder</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="pt-6 text-center">
                    <TrendingDown className="h-8 w-8 text-green-600 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Billigst i dag</h3>
                    <div className="text-2xl font-bold text-green-600">34.2 øre</div>
                    <p className="text-sm text-muted-foreground">kl. 02:00-03:00</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6 text-center">
                    <TrendingUp className="h-8 w-8 text-red-600 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Dyrest i dag</h3>
                    <div className="text-2xl font-bold text-red-600">89.7 øre</div>
                    <p className="text-sm text-muted-foreground">kl. 18:00-19:00</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Calculator className="h-8 w-8 text-primary mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Gjennomsnitt</h3>
                    <div className="text-2xl font-bold text-primary">{currentSpotPrice} øre</div>
                    <p className="text-sm text-muted-foreground">hele døgnet</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Tips Section */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Tips for å spare med spotpris
              </h2>
              
              <div className="space-y-6">
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-3 flex items-center">
                      <Clock className="h-5 w-5 text-primary mr-2" />
                      Flytt forbruk til billige timer
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Kjør oppvaskmaskin, vaskmaskin og elbil-lading om natten eller når prisene er lave.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-3 flex items-center">
                      <Zap className="h-5 w-5 text-primary mr-2" />
                      Følg med på prisvarslinger
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Bruk apper som varsler når strømprisen er lav eller høy, så du kan planlegge forbruket.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-3 flex items-center">
                      <TrendingDown className="h-5 w-5 text-primary mr-2" />
                      Unngå rush-timene
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Prisene er ofte høyest mellom 07-09 og 17-20 når folk kommer hjem fra jobb.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}