import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ComparisonTable } from "@/components/comparison-table"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Zap, TrendingDown, Clock, Shield, Star } from "lucide-react"

const electricityProviders = [
  {
    name: "Fortum",
    rating: 4.1,
    reviews: 8234,
    spotPrice: "57.5 øre/kWh",
    fixedPrice: "89.2 øre/kWh",
    monthlyFee: "29 kr",
    features: ["Spotpris med påslag", "Grønn strøm tilgjengelig", "Kundeservice 24/7"]
  },
  {
    name: "Hafslund",
    rating: 4.0,
    reviews: 12456,
    spotPrice: "59.1 øre/kWh", 
    fixedPrice: "91.5 øre/kWh",
    monthlyFee: "25 kr",
    features: ["Lokal leverandør", "Fastpris garanti", "Digital faktura"]
  },
  {
    name: "Lyse Energi",
    rating: 4.2,
    reviews: 6789,
    spotPrice: "56.8 øre/kWh",
    fixedPrice: "87.9 øre/kWh", 
    monthlyFee: "32 kr",
    features: ["Konkurransedyktige priser", "Norsk vannkraft", "Enkelt å bytte"]}
]

export default function ElectricityPage() {
  console.log("Electricity/Power page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-yellow-50/30 to-green-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center">
                  <Zap className="h-8 w-8 text-yellow-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign strømpriser
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn den billigste strømavtalen for ditt forbruk. Sammenlign spotpris 
                og fastpris fra alle norske strømleverandører.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Test din strømavtale
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Få 3 tilbud
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Facts */}
        <section className="py-12 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <TrendingDown className="h-8 w-8 text-accent mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Spar i snitt 2,800 kr/år</h3>
                  <p className="text-sm text-muted-foreground">
                    Ved å bytte til billigste strømavtale
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Clock className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">2 minutters sammenligning</h3>
                  <p className="text-sm text-muted-foreground">
                    Raskt og enkelt å finne beste tilbud
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Shield className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">25 leverandører</h3>
                  <p className="text-sm text-muted-foreground">
                    Sammenlign alle tilgjengelige tilbud
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Comparison Table */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign strømleverandører
              </h2>
              <p className="text-lg text-muted-foreground">
                Oppdaterte priser og reelle kundeanmeldelser
              </p>
            </div>
            
            <div className="space-y-6">
              {electricityProviders.map((provider, index) => (
                <Card key={provider.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {provider.name}
                          {index === 0 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Billigst
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{provider.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({provider.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Velg tilbud
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      {/* Prices */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">SPOTPRIS</h4>
                        <div className="text-2xl font-bold text-primary">{provider.spotPrice}</div>
                        <div className="text-sm text-muted-foreground">+ nettleie</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FASTPRIS</h4>
                        <div className="text-xl font-semibold">{provider.fixedPrice}</div>
                        <div className="text-sm text-muted-foreground">+ nettleie</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">MÅNEDSAVGIFT</h4>
                        <div className="text-xl font-semibold">{provider.monthlyFee}</div>
                        <div className="text-sm text-muted-foreground">per måned</div>
                      </div>
                      
                      {/* Features */}
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="space-y-2">
                          {provider.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="text-sm">{feature}</div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle 25 strømleverandører
              </Button>
            </div>
          </div>
        </section>

        {/* Info Section */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Hvorfor sammenligne strømpriser?
              </h2>
              
              <div className="prose prose-lg mx-auto text-muted-foreground">
                <p>
                  Strømprisene varierer betydelig mellom leverandører, og ved å sammenligne 
                  kan du spare tusenvis av kroner årlig. Vårt sammenligningstool viser deg 
                  både spotpris og fastpris alternativer.
                </p>
                
                <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">
                  Spotpris vs Fastpris
                </h3>
                <ul className="space-y-2">
                  <li><strong>Spotpris:</strong> Følger markedsprisene time for time</li>
                  <li><strong>Fastpris:</strong> Fast pris over en avtalt periode</li>
                  <li><strong>Variabel pris:</strong> Kombinasjon av spot og fast</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}