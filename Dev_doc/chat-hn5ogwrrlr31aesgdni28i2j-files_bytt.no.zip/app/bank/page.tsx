import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, CreditCard, Calculator, Star, CheckCircle, TrendingDown, Shield } from "lucide-react"

const bankProviders = [
  {
    name: "DNB",
    rating: 4.1,
    reviews: 23456,
    savingsRate: "2.85%",
    loanRate: "Fra 3.95%",
    cardFee: "0 kr/år",
    features: ["Norges største bank", "Omfattende filialnett", "Digitale tjenester", "Bedriftskunder"]
  },
  {
    name: "Nordea",
    rating: 4.0,
    reviews: 18234,
    savingsRate: "2.75%",
    loanRate: "Fra 4.15%", 
    cardFee: "295 kr/år",
    features: ["Nordisk bank", "Godt utvalg produkter", "Personlig rådgivning", "Unge kunder rabatt"]
  },
  {
    name: "Skandiabanken",
    rating: 4.3,
    reviews: 12456,
    savingsRate: "3.10%",
    loanRate: "Fra 3.75%",
    cardFee: "0 kr/år", 
    features: ["Kun nettbank", "Konkurransedyktige renter", "Lav gebyrpolitikk", "Høy sparerrente"]
  }
]

const loanTypes = [
  {
    title: "Boliglån",
    description: "Finansier boligkjøp med konkurransedyktige renter",
    rate: "Fra 3.95%",
    features: ["Opp til 85% av kjøpesummen", "Fleksible nedbetalingsvilkår", "Mulighet for rentefradrag"]
  },
  {
    title: "Forbrukslån",
    description: "Til bil, ferie eller andre større innkjøp",
    rate: "Fra 5.90%",
    features: ["Opp til 600,000 kr", "Løpetid opp til 15 år", "Rask saksbehandling"]
  },
  {
    title: "Kredittkort",
    description: "Praktisk betalingsløsning med kredittramme",
    rate: "Fra 14.90%",
    features: ["Opp til 45 dagers rentefri kreditt", "Bonus og fordeler", "Reiseforsikring inkludert"]
  }
]

export default function BankPage() {
  console.log("Bank and loans page rendering")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-background via-green-50/30 to-blue-50/20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center">
                  <Building2 className="h-8 w-8 text-green-600" />
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-foreground mb-4">
                Sammenlign bank og lån
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Finn den beste banken med lavest renter og beste vilkår. Sammenlign 
                boliglån, forbrukslån og sparekontoer fra alle norske banker.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base px-8">
                  Beregn låneevne
                </Button>
                <Button variant="outline" size="lg" className="text-base px-8">
                  Sammenlign renter
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Stats */}
        <section className="py-12 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <TrendingDown className="h-8 w-8 text-accent mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Spar 15,000 kr/år</h3>
                  <p className="text-sm text-muted-foreground">
                    Ved å refinansiere boliglån
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Calculator className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">3.95% p.a.</h3>
                  <p className="text-sm text-muted-foreground">
                    Laveste boliglånsrente
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <Shield className="h-8 w-8 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">25 banker</h3>
                  <p className="text-sm text-muted-foreground">
                    Sammenlign alle alternativer
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Star className="h-8 w-8 text-yellow-600 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">2 min søknad</h3>
                  <p className="text-sm text-muted-foreground">
                    Rask forhåndsgodkjenning
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Loan Types */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">
              Typer lån og produkter
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {loanTypes.map((loan, index) => (
                <Card key={index} className={index === 0 ? "border-2 border-primary/20" : ""}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      {index === 0 && <Building2 className="h-6 w-6 text-primary" />}
                      {index === 1 && <CreditCard className="h-6 w-6 text-green-600" />}
                      {index === 2 && <Calculator className="h-6 w-6 text-orange-600" />}
                      {loan.title}
                    </CardTitle>
                    <CardDescription>{loan.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-2xl font-bold text-primary">{loan.rate}</div>
                      <ul className="space-y-2 text-sm">
                        {loan.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-accent mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <Button variant="outline" size="sm" className="w-full">
                        Les mer
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Bank Comparison */}
        <section className="py-16 bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Sammenlign banker
              </h2>
              <p className="text-lg text-muted-foreground">
                Renter, gebyrer og tjenester fra Norges banker
              </p>
            </div>
            
            <div className="space-y-6">
              {bankProviders.map((bank, index) => (
                <Card key={bank.name} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-3">
                          {bank.name}
                          {index === 2 && (
                            <Badge className="bg-accent text-accent-foreground">
                              <Star className="h-3 w-3 mr-1" />
                              Beste sparerrente
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="font-semibold ml-1">{bank.rating}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            ({bank.reviews.toLocaleString()} omtaler)
                          </span>
                        </div>
                      </div>
                      
                      <Button className="min-w-[120px]">
                        Søk her
                      </Button>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">SPARERRENTE</h4>
                        <div className="text-2xl font-bold text-primary">{bank.savingsRate}</div>
                        <div className="text-sm text-muted-foreground">p.a.</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">BOLIGLÅN</h4>
                        <div className="text-xl font-semibold">{bank.loanRate}</div>
                        <div className="text-sm text-muted-foreground">p.a.</div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">KORTAVGIFT</h4>
                        <div className="text-xl font-semibold">{bank.cardFee}</div>
                        <div className="text-sm text-muted-foreground">årlig</div>
                      </div>
                      
                      <div className="md:col-span-2">
                        <h4 className="font-semibold text-sm text-muted-foreground mb-3">FORDELER</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                          {bank.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center text-sm">
                              <CheckCircle className="h-3 w-3 text-accent mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center pt-8">
              <Button variant="outline" size="lg">
                Se alle banker og lånetilbud
              </Button>
            </div>
          </div>
        </section>

        {/* Calculator Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">
                Nyttige kalkulatorer
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Calculator className="h-6 w-6 text-primary" />
                      Lånekalulator
                    </CardTitle>
                    <CardDescription>
                      Beregn månedlig terminbeløp og totalkostnad
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full">
                      Åpne kalkulator
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Building2 className="h-6 w-6 text-green-600" />
                      Boliglånskalulator
                    </CardTitle>
                    <CardDescription>
                      Se hvor mye du kan låne til boligkjøp
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full">
                      Beregn låneevne
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}