"use client"

import { Button } from "@/components/ui/button"
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu"
import { Search, Menu, User, ChevronDown, Shield, Zap, Smartphone, Wifi, Building2 } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  console.log("Header component rendering")

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold text-primary">Bytt</h1>
            <span className="ml-1 text-sm text-muted-foreground">.no</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center text-sm font-medium hover:text-primary transition-colors">
                <Shield className="h-4 w-4 mr-2" />
                Forsikring
                <ChevronDown className="h-4 w-4 ml-1" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/forsikring">Alle forsikringer</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/forsikring/bilforsikring">Bilforsikring</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/forsikring/husforsikring">Husforsikring</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/forsikring/reiseforsikring">Reiseforsikring</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center text-sm font-medium hover:text-primary transition-colors">
                <Zap className="h-4 w-4 mr-2" />
                Strøm
                <ChevronDown className="h-4 w-4 ml-1" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/strom">Alle strømavtaler</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/strom/spotpris">Spotpris</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/strom/fastpris">Fastpris</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center text-sm font-medium hover:text-primary transition-colors">
                <Smartphone className="h-4 w-4 mr-2" />
                Mobil
                <ChevronDown className="h-4 w-4 ml-1" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/mobilabonnement">Mobilabonnement</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/mobilabonnement/mobilt-bredband">Mobilt bredbånd</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/mobilabonnement/bedrift">Bedrift</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center text-sm font-medium hover:text-primary transition-colors">
                <Wifi className="h-4 w-4 mr-2" />
                Bredbånd
                <ChevronDown className="h-4 w-4 ml-1" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/bredband">Alle bredbånd</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/bredband/fiber">Fiber</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/bredband/tradlost">Trådløst</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center text-sm font-medium hover:text-primary transition-colors">
                <Building2 className="h-4 w-4 mr-2" />
                Mer
                <ChevronDown className="h-4 w-4 ml-1" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/bank">Bank & lån</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/tv-pakker">TV-pakker</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/varmepumpe">Varmepumpe</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/boligalarm">Boligalarm</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          {/* Search and User Actions */}
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" className="hidden sm:flex">
              <Search className="h-4 w-4 mr-2" />
              Søk
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="hidden sm:flex">
                  <User className="h-4 w-4 mr-2" />
                  Min side
                  <ChevronDown className="h-4 w-4 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-48" align="end">
                <DropdownMenuItem asChild>
                  <Link href="/min-side">Min side</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/min-side">Mine tilbud</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/min-side">Mine meldinger</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/partner">Partner login</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin">Admin</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="lg:hidden border-t bg-background">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <Link href="/forsikring" className="block text-sm font-medium hover:text-primary">
              Forsikring
            </Link>
            <Link href="/strom" className="block text-sm font-medium hover:text-primary">
              Strøm
            </Link>
            <Link href="/mobilabonnement" className="block text-sm font-medium hover:text-primary">
              Mobilabonnement
            </Link>
            <Link href="/bredband" className="block text-sm font-medium hover:text-primary">
              Bredbånd
            </Link>
            <Link href="/bank" className="block text-sm font-medium hover:text-primary">
              Bank & lån
            </Link>
            <div className="pt-4 border-t space-y-2">
              <Button variant="outline" size="sm" className="w-full">
                <Search className="h-4 w-4 mr-2" />
                Søk
              </Button>
              <Link href="/min-side">
                <Button variant="ghost" size="sm" className="w-full">
                  <User className="h-4 w-4 mr-2" />
                  Min side
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}