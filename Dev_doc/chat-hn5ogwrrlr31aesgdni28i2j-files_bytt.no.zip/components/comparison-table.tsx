"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, CheckCircle, ArrowRight } from "lucide-react"

interface Provider {
  name: string
  rating: number
  reviews: number
  carInsurance?: string
  homeInsurance?: string
  travelInsurance?: string
  features: string[]
}

interface ComparisonTableProps {
  providers: Provider[]
  category: string
}

export function ComparisonTable({ providers, category }: ComparisonTableProps) {
  console.log("ComparisonTable rendering for category:", category)

  const handleGetQuote = (providerName: string) => {
    console.log("Get quote clicked for provider:", providerName)
    // Track click event for analytics
  }

  return (
    <div className="space-y-6">
      {providers.map((provider, index) => (
        <Card key={provider.name} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl flex items-center gap-3">
                  {provider.name}
                  {index === 0 && (
                    <Badge className="bg-accent text-accent-foreground">
                      <Star className="h-3 w-3 mr-1" />
                      Best pris
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                    <span className="font-semibold ml-1">{provider.rating}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    ({provider.reviews.toLocaleString()} omtaler)
                  </span>
                </div>
              </div>
              
              <Button 
                className="min-w-[120px]"
                onClick={() => handleGetQuote(provider.name)}
              >
                Få tilbud
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Prices */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm text-muted-foreground">PRISER FRA</h4>
                {provider.carInsurance && (
                  <div>
                    <div className="text-2xl font-bold text-primary">
                      {provider.carInsurance} kr
                    </div>
                    <div className="text-sm text-muted-foreground">Bilforsikring/år</div>
                  </div>
                )}
                {provider.homeInsurance && (
                  <div>
                    <div className="text-xl font-semibold">
                      {provider.homeInsurance} kr
                    </div>
                    <div className="text-sm text-muted-foreground">Husforsikring/år</div>
                  </div>
                )}
                {provider.travelInsurance && (
                  <div>
                    <div className="text-xl font-semibold">
                      {provider.travelInsurance} kr
                    </div>
                    <div className="text-sm text-muted-foreground">Reiseforsikring/år</div>
                  </div>
                )}
              </div>
              
              {/* Features */}
              <div className="md:col-span-1 lg:col-span-3">
                <h4 className="font-semibold text-sm text-muted-foreground mb-4">FORDELER</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {provider.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-accent mr-2 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {/* Show more button */}
      <div className="text-center pt-6">
        <Button variant="outline" size="lg">
          Se alle {providers.length + 5} forsikringsselskaper
        </Button>
      </div>
    </div>
  )
}