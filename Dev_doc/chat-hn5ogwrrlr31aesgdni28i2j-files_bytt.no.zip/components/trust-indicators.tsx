"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Users, 
  Award, 
  Shield, 
  CheckCircle,
  Star,
  TrendingUp
} from "lucide-react"

const stats = [
  {
    number: "150,000+",
    label: "Fornøyde kunder",
    icon: Users,
    color: "text-blue-600"
  },
  {
    number: "85 mill",
    label: "Spart i kroner",
    icon: TrendingUp,
    color: "text-green-600"
  },
  {
    number: "4.8/5",
    label: "Kundescore",
    icon: Star,
    color: "text-yellow-600"
  },
  {
    number: "200+",
    label: "Leverandører",
    icon: Award,
    color: "text-purple-600"
  }
]

const trustElements = [
  {
    title: "100% gratis",
    description: "Vår tjeneste er helt gratis for forbrukere",
    icon: CheckCircle,
    color: "bg-green-50 text-green-700"
  },
  {
    title: "Sikker og trygg",
    description: "GDPR-kompatibel og kryptert databehandling",
    icon: Shield,
    color: "bg-blue-50 text-blue-700"
  },
  {
    title: "Uavhengig sammenligning",
    description: "Vi viser alle tilgjengelige tilbud objektivt",
    icon: Award,
    color: "bg-purple-50 text-purple-700"
  }
]

export function TrustIndicators() {
  console.log("TrustIndicators component rendering")

  return (
    <section className="py-16 bg-gray-50/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Nordmenn stoler på oss
          </h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Siden 2018 har vi hjulpet tusenvis av nordmenn med å spare penger 
            på hverdagsutgifter gjennom smart sammenligning.
          </p>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon
              
              return (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center">
                      <IconComponent className={`h-6 w-6 ${stat.color}`} />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-2">
                    {stat.number}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Trust Elements */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trustElements.map((element, index) => {
            const IconComponent = element.icon
            
            return (
              <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <div className={`w-16 h-16 ${element.color} rounded-full flex items-center justify-center`}>
                      <IconComponent className="h-8 w-8" />
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {element.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {element.description}
                  </p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Certifications */}
        <div className="mt-16 text-center">
          <p className="text-sm text-muted-foreground mb-6">
            Sertifisert og godkjent av:
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <Badge variant="outline" className="text-xs px-4 py-2">
              Forbrukerrådet
            </Badge>
            <Badge variant="outline" className="text-xs px-4 py-2">
              Finanstilsynet
            </Badge>
            <Badge variant="outline" className="text-xs px-4 py-2">
              ISO 27001
            </Badge>
            <Badge variant="outline" className="text-xs px-4 py-2">
              GDPR Compliant
            </Badge>
          </div>
        </div>
      </div>
    </section>
  )
}