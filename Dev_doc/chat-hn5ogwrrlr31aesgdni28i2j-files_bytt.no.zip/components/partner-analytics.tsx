"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { 
  TrendingUp,
  TrendingDown,
  Users,
  MousePointer,
  Target,
  DollarSign,
  Calendar,
  BarChart3,
  Download
} from "lucide-react"

interface PartnerStats {
  totalClicks: number
  totalLeads: number
  conversionRate: number
  estimatedRevenue: number
  lastMonth: {
    clicks: number
    leads: number
    conversionRate: number
    revenue: number
  }
}

interface CampaignData {
  name: string
  clicks: number
  leads: number
  conversionRate: number
  budget: number
  spent: number
  status: 'active' | 'paused' | 'completed'
}

interface TrafficSource {
  source: string
  clicks: number
  leads: number
  percentage: number
}

interface PartnerAnalyticsProps {
  partnerName: string
  category: string
  stats: PartnerStats
  campaigns: CampaignData[]
  trafficSources: TrafficSource[]
  timeframe: string
}

export function PartnerAnalytics({ 
  partnerName, 
  category, 
  stats, 
  campaigns, 
  trafficSources, 
  timeframe 
}: PartnerAnalyticsProps) {
  console.log("Partner analytics rendering for:", partnerName)

  const calculateGrowth = (current: number, previous: number): string => {
    if (previous === 0) return "0"
    return ((current - previous) / previous * 100).toFixed(1)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('no-NO', {
      style: 'currency',
      currency: 'NOK',
      minimumFractionDigits: 0
    }).format(amount)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('no-NO').format(num)
  }

  const clicksGrowth = calculateGrowth(stats.totalClicks, stats.lastMonth.clicks)
  const leadsGrowth = calculateGrowth(stats.totalLeads, stats.lastMonth.leads)
  const revenueGrowth = calculateGrowth(stats.estimatedRevenue, stats.lastMonth.revenue)

  return (
    <div className="space-y-6">
      {/* Partner Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{partnerName}</h2>
          <p className="text-muted-foreground">{category} • {timeframe}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Eksporter data
          </Button>
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            Endre periode
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Klikk til nettside</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(stats.totalClicks)}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              {parseFloat(clicksGrowth) >= 0 ? (
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1 text-red-600" />
              )}
              {clicksGrowth}% fra forrige måned
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Genererte leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(stats.totalLeads)}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              {parseFloat(leadsGrowth) >= 0 ? (
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1 text-red-600" />
              )}
              {leadsGrowth}% fra forrige måned
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Konverteringsrate</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.conversionRate}%</div>
            <div className="text-xs text-muted-foreground">
              Bransjesnitt: 15.2%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Estimert verdi</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.estimatedRevenue)}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              {parseFloat(revenueGrowth) >= 0 ? (
                <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1 text-red-600" />
              )}
              {revenueGrowth}% fra forrige måned
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Campaigns Performance */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Kampanjer</CardTitle>
              <CardDescription>
                Ytelse for dine aktive markedsføringskampanjer
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              Ny kampanje
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {campaigns.map((campaign, index) => (
              <div key={index} className="grid grid-cols-6 gap-4 items-center p-4 border rounded-lg">
                <div>
                  <div className="font-medium">{campaign.name}</div>
                  <Badge 
                    variant={
                      campaign.status === 'active' ? 'default' : 
                      campaign.status === 'paused' ? 'secondary' : 'outline'
                    }
                    className="mt-1"
                  >
                    {campaign.status}
                  </Badge>
                </div>
                
                <div className="text-center">
                  <div className="font-semibold">{formatNumber(campaign.clicks)}</div>
                  <div className="text-xs text-muted-foreground">Klikk</div>
                </div>
                
                <div className="text-center">
                  <div className="font-semibold">{formatNumber(campaign.leads)}</div>
                  <div className="text-xs text-muted-foreground">Leads</div>
                </div>
                
                <div className="text-center">
                  <Badge variant={campaign.conversionRate > 15 ? "default" : "secondary"}>
                    {campaign.conversionRate}%
                  </Badge>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-1">
                    {formatCurrency(campaign.spent)} / {formatCurrency(campaign.budget)}
                  </div>
                  <Progress 
                    value={(campaign.spent / campaign.budget) * 100} 
                    className="h-2"
                  />
                </div>
                
                <div className="text-center">
                  <Button variant="outline" size="sm">
                    Detaljer
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Traffic Sources */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Trafikkkilder</CardTitle>
            <CardDescription>Hvor kommer dine leads fra?</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {trafficSources.map((source, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium">{source.source}</div>
                    <div className="text-sm text-muted-foreground">
                      {formatNumber(source.clicks)} klikk • {formatNumber(source.leads)} leads
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{source.percentage}%</div>
                    <Progress value={source.percentage} className="w-20 h-2 mt-1" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ytelsesmål</CardTitle>
            <CardDescription>Hvordan presterer du mot mål?</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Månedlige leads</span>
                  <span>{stats.totalLeads} / 500</span>
                </div>
                <Progress value={(stats.totalLeads / 500) * 100} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Konverteringsrate</span>
                  <span>{stats.conversionRate}% / 20%</span>
                </div>
                <Progress value={(stats.conversionRate / 20) * 100} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Månedsomsetning</span>
                  <span>{formatCurrency(stats.estimatedRevenue)} / {formatCurrency(100000)}</span>
                </div>
                <Progress value={(stats.estimatedRevenue / 100000) * 100} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}