"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  Shield, 
  Zap, 
  Smartphone, 
  Wifi, 
  ArrowRight,
  TrendingDown,
  Star
} from "lucide-react"

const categories = [
  {
    id: "forsikring",
    title: "Forsikring",
    description: "Sammenlign priser på bil-, hjem- og reiseforsikring",
    icon: Shield,
    color: "bg-blue-500",
    avgSavings: "3,200 kr/år",
    providers: 15,
    popular: true
  },
  {
    id: "strom",
    title: "Strøm",
    description: "Finn billigste strømavtale for ditt forbruk",
    icon: Zap,
    color: "bg-yellow-500",
    avgSavings: "2,800 kr/år",
    providers: 25,
    popular: true
  },
  {
    id: "mobil",
    title: "Mobil",
    description: "Sammenlign mobilabonnementer og dataforfait",
    icon: Smartphone,
    color: "bg-green-500",
    avgSavings: "1,500 kr/år",
    providers: 12,
    popular: false
  },
  {
    id: "internet",
    title: "Internet & TV",
    description: "Finn beste bredbånd og TV-pakker",
    icon: Wifi,
    color: "bg-purple-500",
    avgSavings: "2,100 kr/år",
    providers: 8,
    popular: false
  }
]

export function ServiceCategories() {
  console.log("ServiceCategories component rendering")

  const handleCategoryClick = (categoryId: string) => {
    console.log("Category clicked:", categoryId)
    // Here you would navigate to the comparison page for this category
  }

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Velg hva du vil sammenligne
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Vi hjelper deg med å finne de beste tilbudene innen alle kategorier.
            Sammenlign priser, vilkår og tjenester fra hundrevis av leverandører.
          </p>
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => {
            const IconComponent = category.icon
            
            return (
              <Card 
                key={category.id}
                className="relative hover:shadow-lg transition-all duration-300 cursor-pointer group border-2 hover:border-primary/20"
                onClick={() => handleCategoryClick(category.id)}
              >
                {category.popular && (
                  <Badge 
                    className="absolute -top-2 left-4 bg-accent text-accent-foreground"
                  >
                    <Star className="h-3 w-3 mr-1" />
                    Populær
                  </Badge>
                )}
                
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  
                  <CardTitle className="text-xl font-semibold group-hover:text-primary transition-colors">
                    {category.title}
                  </CardTitle>
                  <CardDescription className="text-sm">
                    {category.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="pt-0">
                  <div className="space-y-3">
                    {/* Average Savings */}
                    <div className="flex items-center text-sm">
                      <TrendingDown className="h-4 w-4 text-accent mr-2" />
                      <span className="text-muted-foreground">Spar i snitt:</span>
                      <span className="font-semibold text-accent ml-1">
                        {category.avgSavings}
                      </span>
                    </div>

                    {/* Provider Count */}
                    <div className="text-sm text-muted-foreground">
                      {category.providers} leverandører tilgjengelig
                    </div>

                    {/* CTA Button */}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleCategoryClick(category.id)
                      }}
                    >
                      Sammenlign nå
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Usikker på hvor du skal begynne?
          </p>
          <Button variant="outline" size="lg">
            Se alle kategorier
          </Button>
        </div>
      </div>
    </section>
  )
}