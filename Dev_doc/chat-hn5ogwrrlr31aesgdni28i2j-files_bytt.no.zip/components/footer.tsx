import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin,
  Mail,
  Phone,
  MapPin
} from "lucide-react"

const footerSections = [
  {
    title: "Tjenester",
    links: [
      { name: "Forsikring", href: "#forsikring" },
      { name: "Strøm", href: "#strom" },
      { name: "Mobil", href: "#mobil" },
      { name: "Internet & TV", href: "#internet" },
      { name: "Bank & lån", href: "#bank" },
      { name: "Alle tjenester", href: "#alle" }
    ]
  },
  {
    title: "Om oss",
    links: [
      { name: "Hvordan vi fungerer", href: "#hvordan" },
      { name: "Om Bytt.no", href: "#om" },
      { name: "Karriere", href: "#karriere" },
      { name: "Presse", href: "#presse" },
      { name: "Partnere", href: "#partnere" }
    ]
  },
  {
    title: "Support",
    links: [
      { name: "Hjelp & FAQ", href: "#hjelp" },
      { name: "Kontakt oss", href: "#kontakt" },
      { name: "Rapporter problem", href: "#problem" },
      { name: "Tilbakemelding", href: "#tilbakemelding" }
    ]
  },
  {
    title: "Juridisk",
    links: [
      { name: "Personvern", href: "#personvern" },
      { name: "Vilkår og betingelser", href: "#vilkar" },
      { name: "Cookie-policy", href: "#cookies" },
      { name: "Klagebehandling", href: "#klage" }
    ]
  }
]

export function Footer() {
  console.log("Footer component rendering")

  return (
    <footer className="bg-slate-50 border-t">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter Section */}
        <div className="py-12 border-b">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-2xl font-semibold text-foreground mb-4">
              Hold deg oppdatert
            </h3>
            <p className="text-muted-foreground mb-6">
              Få tips om sparing og de nyeste tilbudene direkte i innboksen din.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input 
                type="email" 
                placeholder="Din e-postadresse"
                className="flex-1"
              />
              <Button className="sm:w-auto">
                Abonner
              </Button>
            </div>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="flex items-center mb-4">
                <h2 className="text-2xl font-bold text-primary">Bytt</h2>
                <span className="ml-1 text-sm text-muted-foreground">.no</span>
              </div>
              <p className="text-sm text-muted-foreground mb-6 max-w-sm">
                Norges ledende sammenligningstjeneste for forsikring, strøm, 
                mobil og andre hverdagstjenester. Vi hjelper deg å spare penger.
              </p>
              
              {/* Contact Info */}
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  <span>22 00 00 00</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  <span>hei@bytt.no</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Oslo, Norge</span>
                </div>
              </div>
            </div>

            {/* Footer Links */}
            {footerSections.map((section, index) => (
              <div key={index}>
                <h4 className="font-semibold text-foreground mb-4">
                  {section.title}
                </h4>
                <ul className="space-y-2">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a 
                        href={link.href}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Bottom Footer */}
        <div className="py-6 flex flex-col sm:flex-row justify-between items-center">
          <div className="text-sm text-muted-foreground mb-4 sm:mb-0">
            © 2024 Bytt.no. Alle rettigheter reservert.
          </div>
          
          {/* Social Media Links */}
          <div className="flex space-x-4">
            <Button variant="ghost" size="sm" className="p-2">
              <Facebook className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <Twitter className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <Instagram className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <Linkedin className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </footer>
  )
}