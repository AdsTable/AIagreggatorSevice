"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { 
  TrendingUp,
  TrendingDown,
  Users,
  MousePointer,
  Eye,
  DollarSign,
  Building2,
  BarChart3
} from "lucide-react"

interface AnalyticsData {
  totalVisits: number
  totalClicks: number
  totalLeads: number
  revenue: number
  activePartners: number
  conversionRate: number
  monthlyGrowth: number
}

interface CategoryData {
  name: string
  visits: number
  clicks: number
  leads: number
  conversion: number
  revenue: number
}

interface PartnerData {
  name: string
  category: string
  clicks: number
  leads: number
  revenue: number
  conversionRate: number
}

interface AnalyticsDashboardProps {
  data: AnalyticsData
  categoryData: CategoryData[]
  partnerData: PartnerData[]
  timeframe: string
}

export function AnalyticsDashboard({ 
  data, 
  categoryData, 
  partnerData, 
  timeframe 
}: AnalyticsDashboardProps) {
  console.log("Analytics dashboard rendering for timeframe:", timeframe)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('no-NO', {
      style: 'currency',
      currency: 'NOK',
      minimumFractionDigits: 0
    }).format(amount)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('no-NO').format(num)
  }

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Totale besøk</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(data.totalVisits)}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 mr-1 text-green-600" />
              +{data.monthlyGrowth}% fra forrige måned
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Partner klikk</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(data.totalClicks)}</div>
            <div className="text-xs text-muted-foreground">
              Konvertering: {data.conversionRate}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Genererte leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(data.totalLeads)}</div>
            <div className="text-xs text-muted-foreground">
              Kvalifiserte henvendelser
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Estimert inntekt</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(data.revenue)}</div>
            <div className="text-xs text-muted-foreground">
              {data.activePartners} aktive partnere
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Kategori ytelse</CardTitle>
          <CardDescription>
            Sammenligning av trafikk og konvertering per kategori
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {categoryData.map((category, index) => (
              <div key={index} className="grid grid-cols-6 gap-4 items-center p-4 border rounded-lg">
                <div className="font-medium">{category.name}</div>
                <div className="text-center">
                  <div className="font-semibold">{formatNumber(category.visits)}</div>
                  <div className="text-xs text-muted-foreground">Besøk</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">{formatNumber(category.clicks)}</div>
                  <div className="text-xs text-muted-foreground">Klikk</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">{formatNumber(category.leads)}</div>
                  <div className="text-xs text-muted-foreground">Leads</div>
                </div>
                <div className="text-center">
                  <Badge variant={category.conversion > 15 ? "default" : "secondary"}>
                    {category.conversion}%
                  </Badge>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatCurrency(category.revenue)}</div>
                  <div className="text-xs text-muted-foreground">Inntekt</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Partners */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Topp partnere</CardTitle>
              <CardDescription>
                Beste ytelse basert på leads og inntekt
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <BarChart3 className="h-4 w-4 mr-2" />
              Detaljert rapport
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {partnerData.map((partner, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <div className="font-medium">{partner.name}</div>
                    <div className="text-sm text-muted-foreground">{partner.category}</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 gap-6 text-center">
                  <div>
                    <div className="font-semibold">{formatNumber(partner.clicks)}</div>
                    <div className="text-xs text-muted-foreground">Klikk</div>
                  </div>
                  <div>
                    <div className="font-semibold">{formatNumber(partner.leads)}</div>
                    <div className="text-xs text-muted-foreground">Leads</div>
                  </div>
                  <div>
                    <Badge variant={partner.conversionRate > 15 ? "default" : "secondary"}>
                      {partner.conversionRate}%
                    </Badge>
                  </div>
                  <div>
                    <div className="font-semibold">{formatCurrency(partner.revenue)}</div>
                    <div className="text-xs text-muted-foreground">Inntekt</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Real-time Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Sanntids aktivitet</CardTitle>
            <CardDescription>Live trafikk og interaksjoner</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span>Aktive brukere nå:</span>
                <span className="font-semibold">2,341</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Klikk siste time:</span>
                <span className="font-semibold">156</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Nye tilbudsforespørsler:</span>
                <span className="font-semibold">23</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Mest populære kategori:</span>
                <Badge variant="outline">Forsikring</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System status</CardTitle>
            <CardDescription>Infrastruktur og ytelse</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">API responstid:</span>
                <Badge variant="default">123ms</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Oppetid:</span>
                <Badge variant="default">99.9%</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Database status:</span>
                <Badge variant="default">Optimal</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Siste backup:</span>
                <span className="text-sm text-muted-foreground">2 timer siden</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}