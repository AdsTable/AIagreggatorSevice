"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { 
  Building2, 
  Users, 
  TrendingUp,
  MousePointer,
  Eye,
  Settings,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  BarChart3
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface Partner {
  id: string
  name: string
  category: string
  email: string
  phone: string
  status: 'active' | 'pending' | 'suspended'
  clicks: number
  leads: number
  revenue: number
  conversionRate: number
  joinDate: string
  lastLogin: string
}

interface PartnerManagementProps {
  partners: Partner[]
  onAddPartner: () => void
  onEditPartner: (partner: Partner) => void
  onDeletePartner: (partnerId: string) => void
  onToggleStatus: (partnerId: string) => void
}

export function PartnerManagement({ 
  partners, 
  onAddPartner, 
  onEditPartner, 
  onDeletePartner, 
  onToggleStatus 
}: PartnerManagementProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterCategory, setFilterCategory] = useState("all")

  console.log("Partner management component rendering")

  const filteredPartners = partners.filter(partner => {
    const matchesSearch = partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         partner.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || partner.status === filterStatus
    const matchesCategory = filterCategory === "all" || partner.category === filterCategory
    
    return matchesSearch && matchesStatus && matchesCategory
  })

  const totalPartners = partners.length
  const activePartners = partners.filter(p => p.status === 'active').length
  const pendingPartners = partners.filter(p => p.status === 'pending').length
  const totalRevenue = partners.reduce((sum, p) => sum + p.revenue, 0)
  const totalClicks = partners.reduce((sum, p) => sum + p.clicks, 0)

  const categories = Array.from(new Set(partners.map(p => p.category)))

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Totale partnere</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPartners}</div>
            <p className="text-xs text-muted-foreground">Registrerte partnere</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Aktive partnere</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activePartners}</div>
            <p className="text-xs text-muted-foreground">
              {pendingPartners} ventende godkjenning
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Totale klikk</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalClicks.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Denne måneden</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total inntekt</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalRevenue.toLocaleString()} kr</div>
            <p className="text-xs text-muted-foreground">Denne måneden</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Gj.snitt konv.</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(partners.reduce((sum, p) => sum + p.conversionRate, 0) / partners.length).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">Alle partnere</p>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Søk partnere..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <select 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
          >
            <option value="all">Alle statuser</option>
            <option value="active">Aktive</option>
            <option value="pending">Ventende</option>
            <option value="suspended">Suspenderte</option>
          </select>

          <select 
            value={filterCategory} 
            onChange={(e) => setFilterCategory(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
          >
            <option value="all">Alle kategorier</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>

        <Button onClick={onAddPartner}>
          <Plus className="h-4 w-4 mr-2" />
          Legg til partner
        </Button>
      </div>

      {/* Partners Table */}
      <Card>
        <CardHeader>
          <CardTitle>Partnere ({filteredPartners.length})</CardTitle>
          <CardDescription>
            Administrer alle registrerte partnere og deres aktivitet
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPartners.map((partner) => (
              <div key={partner.id} className="grid grid-cols-7 gap-4 items-center p-4 border rounded-lg">
                <div>
                  <div className="font-medium">{partner.name}</div>
                  <div className="text-sm text-muted-foreground">{partner.email}</div>
                  <Badge 
                    variant={
                      partner.status === 'active' ? 'default' : 
                      partner.status === 'pending' ? 'secondary' : 'destructive'
                    }
                    className="mt-1"
                  >
                    {partner.status}
                  </Badge>
                </div>

                <div className="text-center">
                  <div className="font-semibold">{partner.category}</div>
                  <div className="text-sm text-muted-foreground">Kategori</div>
                </div>

                <div className="text-center">
                  <div className="font-semibold">{partner.clicks.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Klikk</div>
                </div>

                <div className="text-center">
                  <div className="font-semibold">{partner.leads}</div>
                  <div className="text-sm text-muted-foreground">Leads</div>
                </div>

                <div className="text-center">
                  <div className="font-semibold">{partner.conversionRate}%</div>
                  <div className="text-sm text-muted-foreground">Konvertering</div>
                </div>

                <div className="text-center">
                  <div className="font-semibold">{partner.revenue.toLocaleString()} kr</div>
                  <div className="text-sm text-muted-foreground">Inntekt</div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => onEditPartner(partner)}>
                    <Eye className="h-4 w-4" />
                  </Button>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onEditPartner(partner)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Rediger
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onToggleStatus(partner.id)}>
                        <Settings className="h-4 w-4 mr-2" />
                        {partner.status === 'active' ? 'Deaktiver' : 'Aktiver'}
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onDeletePartner(partner.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Slett
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}

            {filteredPartners.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Ingen partnere funnet</p>
                <p className="text-sm">Prøv å endre søkekriteriene</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ventende godkjenninger</CardTitle>
            <CardDescription>Partnere som venter på aktivering</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-4">{pendingPartners}</div>
            <Button variant="outline" size="sm" className="w-full">
              Gjennomgå søknader
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ytelsesrapport</CardTitle>
            <CardDescription>Generer månedlig partnerrapport</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-muted-foreground mb-4">
              Siste rapport: {new Date().toLocaleDateString('no-NO')}
            </div>
            <Button variant="outline" size="sm" className="w-full">
              <BarChart3 className="h-4 w-4 mr-2" />
              Generer rapport
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Bulk operasjoner</CardTitle>
            <CardDescription>Utfør handlinger på flere partnere</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button variant="outline" size="sm" className="w-full">
                Send nyhetsbrev
              </Button>
              <Button variant="outline" size="sm" className="w-full">
                Eksporter data
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}