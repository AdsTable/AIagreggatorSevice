"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, TrendingDown, Shield, Clock } from "lucide-react"
import { useState } from "react"

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("")

  console.log("HeroSection component rendering with search query:", searchQuery)

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-blue-50/30 to-green-50/20 py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6">
            Sammenlign og spar
            <span className="text-primary block mt-2">
              tusenvis av kroner
            </span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Finn de beste tilbudene på forsikring, strøm, mobil og internet. 
            Sammenlign priser og vilkår fra Norges ledende leverandører.
          </p>

          {/* Search Bar */}
          <div className="max-w-md mx-auto mb-12">
            <div className="relative">
              <Input
                type="text"
                placeholder="Hva vil du sammenligne?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-12 h-12 text-base"
              />
              <Button 
                size="sm" 
                className="absolute right-1 top-1 h-10"
                onClick={() => console.log("Searching for:", searchQuery)}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Value Propositions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mb-4">
                <TrendingDown className="h-6 w-6 text-accent" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Spar penger</h3>
              <p className="text-sm text-muted-foreground">
                Finn billigere alternativer og reduser dine månedlige utgifter
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Trygt og sikkert</h3>
              <p className="text-sm text-muted-foreground">
                Alle leverandører er verifiserte og følger norske standarder
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Rask sammenligning</h3>
              <p className="text-sm text-muted-foreground">
                Få oversikt over alle tilbud på under 2 minutter
              </p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
            <Button size="lg" className="text-base px-8">
              Start sammenligning
            </Button>
            <Button variant="outline" size="lg" className="text-base px-8">
              Les mer om oss
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}