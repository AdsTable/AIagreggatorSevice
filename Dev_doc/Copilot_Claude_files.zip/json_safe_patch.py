"""
COMPLETE JSON SAFETY SOLUTION
Fixes: ValueError: Out of range float values are not JSON compliant
Author: AdsTable
Created: 2025-05-27 03:43

This patch adds complete recursive handling of infinity and NaN values
in all nested structures: dictionaries, lists, and their combinations.

Apply these functions to replace the corresponding ones in tests_api_Version22.py
"""
import math
import json
from typing import List, Optional, Dict, Any, Union

def json_safe_float(value: Optional[float]) -> Optional[Union[float, str]]:
    """Convert any float to JSON-safe value with infinity handling"""
    if value is None:
        return None
    if math.isinf(value):
        if value > 0:
            return 999999.0  # Large but JSON-safe number for positive infinity
        else:
            return -999999.0  # Large but JSON-safe number for negative infinity
    if math.isnan(value):
        return None  # Convert NaN to None
    return value

def json_safe_list(data: List[Any]) -> List[Any]:
    """Convert list to JSON-safe format with full recursive handling"""
    if not isinstance(data, list):
        return []
    
    result = []
    for item in data:
        if isinstance(item, float):
            result.append(json_safe_float(item))
        elif isinstance(item, dict):
            result.append(json_safe_dict(item))
        elif isinstance(item, list):
            result.append(json_safe_list(item))  # Recursive handling for nested lists
        else:
            result.append(item)
    return result

def json_safe_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert dictionary to JSON-safe format with full recursive handling"""
    if not isinstance(data, dict):
        return {}
    
    result = {}
    for key, value in data.items():
        if isinstance(value, float):
            result[key] = json_safe_float(value)
        elif isinstance(value, dict):
            result[key] = json_safe_dict(value)
        elif isinstance(value, list):
            result[key] = json_safe_list(value)  # Use helper function for lists
        else:
            result[key] = value
    return result

def safe_json_dumps(obj: Any, **kwargs) -> str:
    """Enhanced JSON dumps with complete safe float handling"""
    # First apply recursive safety conversion to the entire object
    if isinstance(obj, dict):
        obj = json_safe_dict(obj)
    elif isinstance(obj, list):
        obj = json_safe_list(obj)
        
    # Then handle any remaining cases with the serializer
    def json_serializer(obj):
        if isinstance(obj, float):
            if math.isinf(obj):
                return 999999.0 if obj > 0 else -999999.0
            if math.isnan(obj):
                return None
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
    
    return json.dumps(obj, default=json_serializer, **kwargs)

# Enhanced method for StandardizedProduct class
def enhanced_to_json_safe_dict(self) -> Dict[str, Any]:
    """Enhanced JSON-safe dictionary conversion for StandardizedProduct"""
    # Start with all attributes
    data = {}
    for field_name in ['source_url', 'category', 'name', 'provider_name', 'product_id', 
                      'description', 'price_kwh', 'standing_charge', 'contract_type',
                      'monthly_cost', 'contract_duration_months', 'data_gb', 'calls',
                      'texts', 'network_type', 'download_speed', 'upload_speed',
                      'connection_type', 'data_cap_gb', 'available', 'raw_data']:
        if hasattr(self, field_name):
            value = getattr(self, field_name)
            if isinstance(value, float):
                data[field_name] = json_safe_float(value)
            elif isinstance(value, dict):
                data[field_name] = json_safe_dict(value)
            elif isinstance(value, list):
                data[field_name] = json_safe_list(value)
            else:
                data[field_name] = value
    return data