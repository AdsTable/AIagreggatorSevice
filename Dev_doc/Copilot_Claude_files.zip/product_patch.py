# If using actual models
if USE_ACTUAL_MODELS:
    # Update the to_json_safe_dict method
    StandardizedProduct.to_json_safe_dict = enhanced_to_json_safe_dict
else:
    # Update embedded StandardizedProduct class
    @dataclass
    class StandardizedProduct:
        # [existing fields...]
        
        def to_json_safe_dict(self) -> Dict[str, Any]:
            """JSON-safe dictionary conversion"""
            data = {
                'source_url': self.source_url,
                'category': self.category,
                'name': self.name,
                'provider_name': self.provider_name,
                'product_id': self.product_id,
                'description': self.description,
                'price_kwh': json_safe_float(self.price_kwh),
                'standing_charge': json_safe_float(self.standing_charge),
                'contract_type': self.contract_type,
                'monthly_cost': json_safe_float(self.monthly_cost),
                'contract_duration_months': self.contract_duration_months,
                'data_gb': json_safe_float(self.data_gb),
                'calls': json_safe_float(self.calls),
                'texts': json_safe_float(self.texts),
                'network_type': self.network_type,
                'download_speed': json_safe_float(self.download_speed),
                'upload_speed': json_safe_float(self.upload_speed),
                'connection_type': self.connection_type,
                'data_cap_gb': json_safe_float(self.data_cap_gb),
                'available': self.available,
                'raw_data': json_safe_dict(self.raw_data)
            }
            return data