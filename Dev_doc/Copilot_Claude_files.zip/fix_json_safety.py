def json_safe_list(data: List[Any]) -> List[Any]:
    """Convert list to JSON-safe format recursively"""
    if not isinstance(data, list):
        return []
    
    result = []
    for item in data:
        if isinstance(item, float):
            result.append(json_safe_float(item))
        elif isinstance(item, dict):
            result.append(json_safe_dict(item))
        elif isinstance(item, list):
            result.append(json_safe_list(item))  # Recursive call for nested lists
        else:
            result.append(item)
    return result

# Update the json_safe_dict function to use json_safe_list
def json_safe_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert dictionary to JSON-safe format"""
    if not isinstance(data, dict):
        return {}
    
    result = {}
    for key, value in data.items():
        if isinstance(value, float):
            result[key] = json_safe_float(value)
        elif isinstance(value, dict):
            result[key] = json_safe_dict(value)
        elif isinstance(value, list):
            result[key] = json_safe_list(value)  # Use helper function for lists
        else:
            result[key] = value
    return result