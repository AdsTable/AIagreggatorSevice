def add_products(self, products: List[StandardizedProduct]):
    """Add products to database with enhanced JSON safety check"""
    safe_products = []
    for product in products:
        # Create a fully JSON-safe copy
        safe_product_data = {
            'source_url': product.source_url,
            'category': product.category,
            'name': product.name,
            'provider_name': getattr(product, 'provider_name', ""),
            'product_id': getattr(product, 'product_id', None),
            'description': getattr(product, 'description', None),
            'price_kwh': json_safe_float(getattr(product, 'price_kwh', None)),
            'standing_charge': json_safe_float(getattr(product, 'standing_charge', None)),
            'contract_type': getattr(product, 'contract_type', None),
            'monthly_cost': json_safe_float(getattr(product, 'monthly_cost', None)),
            'contract_duration_months': getattr(product, 'contract_duration_months', None),
            'data_gb': json_safe_float(getattr(product, 'data_gb', None)),
            'calls': json_safe_float(getattr(product, 'calls', None)),
            'texts': json_safe_float(getattr(product, 'texts', None)),
            'network_type': getattr(product, 'network_type', None),
            'download_speed': json_safe_float(getattr(product, 'download_speed', None)),
            'upload_speed': json_safe_float(getattr(product, 'upload_speed', None)),
            'connection_type': getattr(product, 'connection_type', None),
            'data_cap_gb': json_safe_float(getattr(product, 'data_cap_gb', None)),
            'available': getattr(product, 'available', True),
            'raw_data': json_safe_dict(getattr(product, 'raw_data', {}))
        }
        
        safe_product = StandardizedProduct(**safe_product_data)
        safe_products.append(safe_product)
    
    self.products.extend(safe_products)
    print(f"📦 Added {len(products)} JSON-safe products. Total: {len(self.products)}")