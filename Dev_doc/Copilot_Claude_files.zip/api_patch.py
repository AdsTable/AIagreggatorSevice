@self.app.get("/search")
async def search_endpoint(
    product_type: Optional[str] = None,
    provider: Optional[str] = None,
    available_only: bool = False
):
    try:
        # Get JSON-safe results
        results = await json_safe_search_and_filter_products(
            None, 
            product_type=product_type,
            provider=provider, 
            available_only=available_only
        )
        
        # Enhanced double JSON safety check
        safe_results = json_safe_list(results)
        json_str = safe_json_dumps(safe_results)
        return json.loads(json_str)
        
    except Exception as e:
        print(f"❌ API Error: {e}")
        return {"error": str(e), "results": []}