# === JSON-SAFE UTILITY FUNCTIONS ===

def json_safe_float(value: Optional[float]) -> Optional[Union[float, str]]:
    """Convert float to JSON-safe value"""
    if value is None:
        return None
    if math.isinf(value):
        if value > 0:
            return 999999.0  # Large but JSON-safe number for positive infinity
        else:
            return -999999.0  # Large but JSON-safe number for negative infinity
    if math.isnan(value):
        return None  # Convert NaN to None
    return value

def json_safe_list(data: List[Any]) -> List[Any]:
    """Convert list to JSON-safe format recursively"""
    if not isinstance(data, list):
        return []
    
    result = []
    for item in data:
        if isinstance(item, float):
            result.append(json_safe_float(item))
        elif isinstance(item, dict):
            result.append(json_safe_dict(item))
        elif isinstance(item, list):
            result.append(json_safe_list(item))  # Recursive call for nested lists
        else:
            result.append(item)
    return result

def json_safe_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert dictionary to JSON-safe format"""
    if not isinstance(data, dict):
        return {}
    
    result = {}
    for key, value in data.items():
        if isinstance(value, float):
            result[key] = json_safe_float(value)
        elif isinstance(value, dict):
            result[key] = json_safe_dict(value)
        elif isinstance(value, list):
            result[key] = json_safe_list(value)  # Use helper function for lists
        else:
            result[key] = value
    return result

def safe_json_dumps(obj: Any, **kwargs) -> str:
    """JSON dumps with safe float handling"""
    def json_serializer(obj):
        if isinstance(obj, float):
            if math.isinf(obj):
                return 999999.0 if obj > 0 else -999999.0
            if math.isnan(obj):
                return None
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
    
    # Process complex objects before serializing
    if isinstance(obj, dict):
        obj = json_safe_dict(obj)
    elif isinstance(obj, list):
        obj = json_safe_list(obj)
    
    return json.dumps(obj, default=json_serializer, **kwargs)