import React from 'react';
import { MoreHorizontal } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

interface ChartCardProps {
  title: string;
  children: React.ReactNode;
  showActions?: boolean;
}

const ChartCard: React.FC<ChartCardProps> = ({ 
  title, 
  children,
  showActions = true
}) => {
  const { theme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  
  return (
    <div className={`${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md`}>
      <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
        <h3 className="font-medium">{title}</h3>
        
        {showActions && (
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`p-1 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} transition-colors`}
            >
              <MoreHorizontal size={18} />
            </button>
            
            {isMenuOpen && (
              <div className={`absolute right-0 top-full mt-1 w-48 rounded-md shadow-lg ${theme === 'dark' ? 'bg-gray-700' : 'bg-white'} ring-1 ring-black ring-opacity-5 z-10`}>
                <div className="py-1" role="menu" aria-orientation="vertical">
                  <button 
                    className={`block w-full text-left px-4 py-2 text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-600' : 'text-gray-700 hover:bg-gray-100'}`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Download CSV
                  </button>
                  <button 
                    className={`block w-full text-left px-4 py-2 text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-600' : 'text-gray-700 hover:bg-gray-100'}`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    View Full Report
                  </button>
                  <button 
                    className={`block w-full text-left px-4 py-2 text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-600' : 'text-gray-700 hover:bg-gray-100'}`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Customize Chart
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="p-4">
        {children}
      </div>
    </div>
  );
};

export default ChartCard;