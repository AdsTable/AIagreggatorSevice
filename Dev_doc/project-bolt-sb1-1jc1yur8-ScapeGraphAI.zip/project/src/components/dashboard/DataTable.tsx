import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { 
  ChevronDown, 
  ChevronUp, 
  ChevronsUpDown,
  ArrowLeft,
  ArrowRight,
  MoreHorizontal,
  Download,
  Filter
} from 'lucide-react';

interface Column {
  id: string;
  header: string;
  accessor: (row: any) => React.ReactNode;
  sortable?: boolean;
}

interface DataTableProps {
  columns: Column[];
  data: any[];
  title?: string;
}

const DataTable: React.FC<DataTableProps> = ({ columns, data, title }) => {
  const { theme } = useTheme();
  const [sortConfig, setSortConfig] = React.useState<{ key: string | null; direction: 'asc' | 'desc' } | null>(null);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [showFilters, setShowFilters] = React.useState(false);

  const sortedData = React.useMemo(() => {
    let sortableItems = [...data];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [data, sortConfig]);

  const currentTableData = React.useMemo(() => {
    const firstPageIndex = (currentPage - 1) * rowsPerPage;
    const lastPageIndex = firstPageIndex + rowsPerPage;
    return sortedData.slice(firstPageIndex, lastPageIndex);
  }, [sortedData, currentPage, rowsPerPage]);

  const totalPages = Math.ceil(data.length / rowsPerPage);

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (columnId: string) => {
    if (!sortConfig || sortConfig.key !== columnId) {
      return <ChevronsUpDown size={16} className="ml-1 text-gray-400" />;
    }
    return sortConfig.direction === 'asc' 
      ? <ChevronUp size={16} className="ml-1 text-blue-500" /> 
      : <ChevronDown size={16} className="ml-1 text-blue-500" />;
  };

  return (
    <div className={`${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} rounded-lg shadow-sm overflow-hidden transition-all duration-200`}>
      {title && (
        <div className={`px-6 py-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
          <div className="flex justify-between items-center">
            <h3 className="font-medium">{title}</h3>
            <div className="flex space-x-2">
              <button 
                className={`p-2 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} transition-colors`}
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={16} className={showFilters ? 'text-blue-500' : ''} />
              </button>
              <button 
                className={`p-2 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} transition-colors`}
              >
                <Download size={16} />
              </button>
              <button 
                className={`p-2 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} transition-colors`}
              >
                <MoreHorizontal size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
      
      {showFilters && (
        <div className={`px-6 py-3 ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'} border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
          <div className="flex flex-wrap gap-2">
            <input
              type="text"
              placeholder="Search..."
              className={`text-sm px-3 py-1.5 rounded-md ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-300'} border focus:outline-none focus:ring-2 focus:ring-blue-500`}
            />
            <select 
              className={`text-sm px-3 py-1.5 rounded-md ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-300'} border focus:outline-none focus:ring-2 focus:ring-blue-500`}
            >
              <option value="">Status: All</option>
              <option value="active">Status: Active</option>
              <option value="inactive">Status: Inactive</option>
            </select>
            <button 
              className={`text-sm px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded-md transition-colors`}
            >
              Apply Filters
            </button>
          </div>
        </div>
      )}
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className={`${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'}`}>
            <tr>
              {columns.map((column) => (
                <th 
                  key={column.id}
                  className={`px-6 py-3 text-left text-xs font-medium ${
                    theme === 'dark' ? 'text-gray-300' : 'text-gray-500'
                  } uppercase tracking-wider`}
                >
                  {column.sortable !== false ? (
                    <button 
                      className="flex items-center focus:outline-none"
                      onClick={() => requestSort(column.id)}
                    >
                      {column.header}
                      {getSortIcon(column.id)}
                    </button>
                  ) : (
                    column.header
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className={`divide-y ${theme === 'dark' ? 'divide-gray-700' : 'divide-gray-200'}`}>
            {currentTableData.map((row, rowIndex) => (
              <tr 
                key={rowIndex} 
                className={`${
                  theme === 'dark' 
                    ? 'hover:bg-gray-700' 
                    : 'hover:bg-gray-50'
                } transition-colors`}
              >
                {columns.map((column) => (
                  <td 
                    key={`${rowIndex}-${column.id}`} 
                    className="px-6 py-4 whitespace-nowrap text-sm"
                  >
                    {column.accessor(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className={`px-6 py-3 ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'} border-t ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
        <div className="flex justify-between items-center">
          <div>
            <select
              className={`text-sm rounded-md ${theme === 'dark' ? 'bg-gray-800 text-white border-gray-700' : 'bg-white text-gray-700 border-gray-300'} border px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500`}
              value={rowsPerPage}
              onChange={(e) => {
                setRowsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
            >
              {[5, 10, 20, 50].map((pageSize) => (
                <option key={pageSize} value={pageSize}>
                  {pageSize} rows
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              className={`p-1.5 rounded-md ${theme === 'dark' ? 'bg-gray-800 hover:bg-gray-900' : 'bg-white hover:bg-gray-100'} ${theme === 'dark' ? 'text-gray-300' : 'text-gray-500'} disabled:opacity-50 disabled:cursor-not-allowed transition-colors`}
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ArrowLeft size={16} />
            </button>
            <span className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-500'}`}>
              Page {currentPage} of {totalPages}
            </span>
            <button
              className={`p-1.5 rounded-md ${theme === 'dark' ? 'bg-gray-800 hover:bg-gray-900' : 'bg-white hover:bg-gray-100'} ${theme === 'dark' ? 'text-gray-300' : 'text-gray-500'} disabled:opacity-50 disabled:cursor-not-allowed transition-colors`}
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataTable;