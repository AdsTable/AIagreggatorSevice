import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: {
    value: number;
    isPositive: boolean;
  };
  color?: 'blue' | 'green' | 'purple' | 'amber';
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon, 
  change,
  color = 'blue'
}) => {
  const { theme } = useTheme();
  
  const getColorClass = (colorName: string) => {
    const colorMap: Record<string, { bg: string, bgLight: string, text: string, iconBg: string }> = {
      blue: {
        bg: theme === 'dark' ? 'bg-blue-900/20' : 'bg-blue-50',
        bgLight: theme === 'dark' ? 'bg-blue-900/10' : 'bg-blue-50/50',
        text: 'text-blue-600 dark:text-blue-400',
        iconBg: theme === 'dark' ? 'bg-blue-900/30' : 'bg-blue-100',
      },
      green: {
        bg: theme === 'dark' ? 'bg-green-900/20' : 'bg-green-50',
        bgLight: theme === 'dark' ? 'bg-green-900/10' : 'bg-green-50/50',
        text: 'text-green-600 dark:text-green-400',
        iconBg: theme === 'dark' ? 'bg-green-900/30' : 'bg-green-100',
      },
      purple: {
        bg: theme === 'dark' ? 'bg-purple-900/20' : 'bg-purple-50',
        bgLight: theme === 'dark' ? 'bg-purple-900/10' : 'bg-purple-50/50',
        text: 'text-purple-600 dark:text-purple-400',
        iconBg: theme === 'dark' ? 'bg-purple-900/30' : 'bg-purple-100',
      },
      amber: {
        bg: theme === 'dark' ? 'bg-amber-900/20' : 'bg-amber-50',
        bgLight: theme === 'dark' ? 'bg-amber-900/10' : 'bg-amber-50/50',
        text: 'text-amber-600 dark:text-amber-400',
        iconBg: theme === 'dark' ? 'bg-amber-900/30' : 'bg-amber-100',
      },
    };

    return colorMap[colorName] || colorMap.blue;
  };
  
  const colorClass = getColorClass(color);
  
  return (
    <div className={`${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-sm p-6 transition-all duration-200 hover:shadow-md`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">{title}</p>
          <h3 className="text-2xl font-bold">{value}</h3>
          
          {change && (
            <div className="flex items-center mt-2">
              <span className={`flex items-center text-xs font-medium ${change.isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                {change.isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                <span className="ml-1">{change.value}%</span>
              </span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last period</span>
            </div>
          )}
        </div>
        
        <div className={`p-3 rounded-md ${colorClass.iconBg}`}>
          {icon}
        </div>
      </div>
      
      <div className="mt-4">
        <div className="bg-gray-200 dark:bg-gray-700 h-1 rounded-full overflow-hidden">
          <div className={`${colorClass.bg} h-1 rounded-full`} style={{ width: '70%' }}></div>
        </div>
      </div>
    </div>
  );
};

export default StatCard;