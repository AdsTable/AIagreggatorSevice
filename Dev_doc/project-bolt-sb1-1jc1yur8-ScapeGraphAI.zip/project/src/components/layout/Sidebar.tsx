import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Database, 
  Users, 
  Settings, 
  BarChart2, 
  FileText,
  HelpCircle,
  LogOut
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const Sidebar: React.FC = () => {
  const { theme } = useTheme();
  const [expanded, setExpanded] = useState(true);

  const navItems = [
    { name: 'Dashboard', icon: <LayoutDashboard size={20} />, path: '/dashboard' },
    { name: 'Data Tables', icon: <Database size={20} />, path: '/data' },
    { name: 'Analytics', icon: <BarChart2 size={20} />, path: '/analytics' },
    { name: 'Reports', icon: <FileText size={20} />, path: '/reports' },
    { name: 'User Management', icon: <Users size={20} />, path: '/users' },
    { name: 'Settings', icon: <Settings size={20} />, path: '/settings' },
  ];

  return (
    <div 
      className={`${expanded ? 'w-64' : 'w-20'} h-full fixed left-0 top-16 flex-shrink-0 transition-all duration-300 ease-in-out z-20 ${
        theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'
      } border-r ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}
    >
      <button
        onClick={() => setExpanded(!expanded)}
        className={`hidden md:flex absolute -right-3 top-10 bg-blue-500 text-white rounded-full p-1 shadow-lg hover:bg-blue-600 focus:outline-none`}
      >
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className={`h-4 w-4 transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`} 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>
      
      <div className="py-4">
        <div className="mb-8">
          <ul className="space-y-2 px-4">
            {navItems.map((item) => (
              <li key={item.name}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => 
                    `flex items-center py-2 px-3 rounded-md transition-colors duration-200
                    ${isActive 
                      ? theme === 'dark' 
                        ? 'bg-gray-700 text-white' 
                        : 'bg-blue-50 text-blue-700' 
                      : theme === 'dark' 
                        ? 'text-gray-300 hover:bg-gray-700' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`
                  }
                >
                  <span className="mr-4">{item.icon}</span>
                  {expanded && <span className="transition-opacity duration-200">{item.name}</span>}
                </NavLink>
              </li>
            ))}
          </ul>
        </div>

        <div className="px-4 mt-auto">
          <div className={`border-t ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'} pt-4`}>
            <ul className="space-y-2">
              <li>
                <a 
                  href="#" 
                  className={`flex items-center py-2 px-3 rounded-md transition-colors duration-200 ${
                    theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <span className="mr-4"><HelpCircle size={20} /></span>
                  {expanded && <span className="transition-opacity duration-200">Help & Support</span>}
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className={`flex items-center py-2 px-3 rounded-md transition-colors duration-200 ${
                    theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <span className="mr-4"><LogOut size={20} /></span>
                  {expanded && <span className="transition-opacity duration-200">Log Out</span>}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;