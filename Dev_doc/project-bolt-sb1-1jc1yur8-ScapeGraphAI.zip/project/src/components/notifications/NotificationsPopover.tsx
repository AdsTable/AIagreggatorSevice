import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Bell, Info, AlertTriangle, CheckCircle } from 'lucide-react';

interface NotificationsPopoverProps {
  onClose: () => void;
}

const NotificationsPopover: React.FC<NotificationsPopoverProps> = ({ onClose }) => {
  const { theme } = useTheme();
  
  const notifications = [
    { id: 1, type: 'info', message: 'New data available for analysis', time: '5 minutes ago' },
    { id: 2, type: 'warning', message: 'API usage approaching limit', time: '1 hour ago' },
    { id: 3, type: 'success', message: 'Report successfully generated', time: '3 hours ago' },
    { id: 4, type: 'info', message: 'New user joined your team', time: '1 day ago' },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'info':
        return <Info size={16} className="text-blue-500" />;
      case 'warning':
        return <AlertTriangle size={16} className="text-amber-500" />;
      case 'success':
        return <CheckCircle size={16} className="text-green-500" />;
      default:
        return <Bell size={16} />;
    }
  };

  const getBackgroundColor = (type: string) => {
    switch (type) {
      case 'info':
        return theme === 'dark' ? 'bg-blue-900/20' : 'bg-blue-50';
      case 'warning':
        return theme === 'dark' ? 'bg-amber-900/20' : 'bg-amber-50';
      case 'success':
        return theme === 'dark' ? 'bg-green-900/20' : 'bg-green-50';
      default:
        return theme === 'dark' ? 'bg-gray-800' : 'bg-white';
    }
  };

  return (
    <div 
      className={`absolute right-0 top-12 w-80 shadow-lg rounded-md p-2 ${
        theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'
      }`}
    >
      <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-700">
        <h3 className="font-medium">Notifications</h3>
        <button 
          className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
          onClick={() => {}}
        >
          Mark all as read
        </button>
      </div>
      
      <div className="max-h-96 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            <p>No notifications yet</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {notifications.map((notification) => (
              <li key={notification.id} className={`${getBackgroundColor(notification.type)} p-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors`}>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-0.5">
                    {getIcon(notification.type)}
                  </div>
                  <div className="ml-3 flex-1">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{notification.time}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      
      <div className="p-3 text-center border-t border-gray-200 dark:border-gray-700">
        <button 
          className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
          onClick={() => {}}
        >
          View all notifications
        </button>
      </div>
    </div>
  );
};

export default NotificationsPopover;