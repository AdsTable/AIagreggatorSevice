import React from 'react';
import { useTheme } from '../context/ThemeContext';
import DataTable from '../components/dashboard/DataTable';
import { Search, Download, Filter, PlusCircle } from 'lucide-react';

const DataTables: React.FC = () => {
  const { theme } = useTheme();

  // Mock data for data sources table
  const dataSources = [
    { id: 1, name: "Customer Database", type: "PostgreSQL", status: "Active", lastSync: "10 mins ago", size: "1.2 GB" },
    { id: 2, name: "Marketing Analytics", type: "BigQuery", status: "Active", lastSync: "32 mins ago", size: "4.7 GB" },
    { id: 3, name: "Sales Reports", type: "MySQL", status: "Active", lastSync: "1 hour ago", size: "865 MB" },
    { id: 4, name: "Website Logs", type: "MongoDB", status: "Inactive", lastSync: "3 days ago", size: "3.1 GB" },
    { id: 5, name: "Product Catalog", type: "PostgreSQL", status: "Active", lastSync: "25 mins ago", size: "512 MB" },
    { id: 6, name: "User Activity", type: "Redshift", status: "Active", lastSync: "5 mins ago", size: "7.8 GB" },
    { id: 7, name: "Social Media", type: "API", status: "Error", lastSync: "Failed", size: "N/A" },
  ];

  const dataSourceColumns = [
    {
      id: 'name',
      header: 'Name',
      accessor: (row: any) => (
        <div>
          <p className="font-medium">{row.name}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">ID: {row.id}</p>
        </div>
      ),
    },
    {
      id: 'type',
      header: 'Type',
      accessor: (row: any) => row.type,
    },
    {
      id: 'status',
      header: 'Status',
      accessor: (row: any) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          row.status === 'Active' 
            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
            : row.status === 'Inactive' 
              ? 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400'
              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
        }`}>
          {row.status}
        </div>
      ),
    },
    {
      id: 'lastSync',
      header: 'Last Sync',
      accessor: (row: any) => row.lastSync,
    },
    {
      id: 'size',
      header: 'Size',
      accessor: (row: any) => row.size,
    },
    {
      id: 'actions',
      header: 'Actions',
      sortable: false,
      accessor: () => (
        <div className="flex space-x-2">
          <button className={`p-1 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} text-blue-500`}>
            View
          </button>
          <button className={`p-1 rounded-md ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} text-blue-500`}>
            Edit
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="container mx-auto pb-12 pt-6 pl-20 md:pl-0">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Data Tables</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Manage your data sources and tables.
        </p>
      </div>

      <div className="mb-8">
        <div className={`p-6 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-sm`}>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search data sources..."
                className={`block w-full pl-10 pr-3 py-2 rounded-md border ${
                  theme === 'dark' 
                    ? 'bg-gray-700 border-gray-600 text-gray-100' 
                    : 'bg-white border-gray-300 text-gray-900'
                } focus:outline-none focus:ring-2 focus:ring-blue-500`}
              />
            </div>
            <div className="flex space-x-2 shrink-0">
              <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors`}>
                <Filter size={16} className="mr-2" />
                <span>Filter</span>
              </button>
              <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors`}>
                <Download size={16} className="mr-2" />
                <span>Export</span>
              </button>
              <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white transition-colors`}>
                <PlusCircle size={16} className="mr-2" />
                <span>New Source</span>
              </button>
            </div>
          </div>

          <DataTable 
            columns={dataSourceColumns} 
            data={dataSources} 
          />
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Recent Tables</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div 
              key={i} 
              className={`p-6 ${theme === 'dark' ? 'bg-gray-800 hover:bg-gray-750' : 'bg-white hover:bg-gray-50'} rounded-lg shadow-sm cursor-pointer transition-all duration-200`}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-medium">Table Name {i}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Last updated: 2 hours ago</p>
                </div>
                <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  i % 3 === 0 
                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' 
                    : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                }`}>
                  {i % 3 === 0 ? 'Processing' : 'Ready'}
                </div>
              </div>
              <div className="space-y-2">
                <div className={`h-2 w-full rounded-full ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'}`}>
                  <div className="h-2 rounded-full bg-blue-500" style={{ width: `${65 + (i * 5) % 30}%` }}></div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>{Math.floor(1000 + i * 568)} rows</span>
                  <span>{(i * 0.25 + 0.5).toFixed(2)} GB</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DataTables;