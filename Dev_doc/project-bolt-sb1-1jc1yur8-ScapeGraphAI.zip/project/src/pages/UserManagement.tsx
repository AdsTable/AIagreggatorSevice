import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import DataTable from '../components/dashboard/DataTable';
import { Search, UserPlus, Filter } from 'lucide-react';

const UserManagement: React.FC = () => {
  const { theme } = useTheme();
  const [selectedTab, setSelectedTab] = useState('users');
  
  // Mock user data
  const users = [
    { id: 1, name: "John Smith", email: "john.smith@example.com", role: "Admin", status: "Active", lastActive: "5 mins ago" },
    { id: 2, name: "Emily Johnson", email: "emily.j@example.com", role: "Analyst", status: "Active", lastActive: "2 hours ago" },
    { id: 3, name: "Michael Wong", email: "m.wong@example.com", role: "Viewer", status: "Active", lastActive: "Yesterday" },
    { id: 4, name: "Sarah Davis", email: "sarah.d@example.com", role: "Analyst", status: "Inactive", lastActive: "2 weeks ago" },
    { id: 5, name: "Robert Garcia", email: "r.garcia@example.com", role: "Admin", status: "Active", lastActive: "Just now" },
    { id: 6, name: "Lisa Chen", email: "lisa.c@example.com", role: "Viewer", status: "Active", lastActive: "3 days ago" },
  ];

  // Table columns
  const userColumns = [
    {
      id: 'name',
      header: 'Name',
      accessor: (row: any) => (
        <div>
          <p className="font-medium">{row.name}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{row.email}</p>
        </div>
      ),
    },
    {
      id: 'role',
      header: 'Role',
      accessor: (row: any) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          row.role === 'Admin' 
            ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400' 
            : row.role === 'Analyst'
              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' 
              : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
        }`}>
          {row.role}
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      accessor: (row: any) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          row.status === 'Active' 
            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
        }`}>
          {row.status}
        </div>
      ),
    },
    {
      id: 'lastActive',
      header: 'Last Active',
      accessor: (row: any) => row.lastActive,
    },
    {
      id: 'actions',
      header: 'Actions',
      sortable: false,
      accessor: () => (
        <div className="flex space-x-2">
          <button className={`text-sm text-blue-500 hover:text-blue-700 dark:hover:text-blue-300 transition-colors`}>
            Edit
          </button>
          <button className={`text-sm text-red-500 hover:text-red-700 dark:hover:text-red-300 transition-colors`}>
            Deactivate
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="container mx-auto pb-12 pt-6 pl-20 md:pl-0">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">User Management</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Manage users, roles, and permissions.
        </p>
      </div>

      {/* Tabs */}
      <div className="mb-8 border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          <button
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
              selectedTab === 'users'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : `border-transparent ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} hover:border-gray-300`
            }`}
            onClick={() => setSelectedTab('users')}
          >
            Users
          </button>
          <button
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
              selectedTab === 'roles'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : `border-transparent ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} hover:border-gray-300`
            }`}
            onClick={() => setSelectedTab('roles')}
          >
            Roles
          </button>
          <button
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
              selectedTab === 'teams'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : `border-transparent ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} hover:border-gray-300`
            }`}
            onClick={() => setSelectedTab('teams')}
          >
            Teams
          </button>
          <button
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
              selectedTab === 'permissions'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : `border-transparent ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} hover:border-gray-300`
            }`}
            onClick={() => setSelectedTab('permissions')}
          >
            Permissions
          </button>
        </nav>
      </div>

      <div className="mb-8">
        <div className={`p-6 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-sm`}>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search users..."
                className={`block w-full pl-10 pr-3 py-2 rounded-md border ${
                  theme === 'dark' 
                    ? 'bg-gray-700 border-gray-600 text-gray-100' 
                    : 'bg-white border-gray-300 text-gray-900'
                } focus:outline-none focus:ring-2 focus:ring-blue-500`}
              />
            </div>
            <div className="flex space-x-2 shrink-0">
              <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors`}>
                <Filter size={16} className="mr-2" />
                <span>Filter</span>
              </button>
              <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white transition-colors`}>
                <UserPlus size={16} className="mr-2" />
                <span>Add User</span>
              </button>
            </div>
          </div>

          {selectedTab === 'users' && (
            <DataTable 
              columns={userColumns} 
              data={users} 
            />
          )}
          
          {selectedTab === 'roles' && (
            <div className="py-8 text-center text-gray-500 dark:text-gray-400">
              <p>Role management interface would be displayed here.</p>
            </div>
          )}
          
          {selectedTab === 'teams' && (
            <div className="py-8 text-center text-gray-500 dark:text-gray-400">
              <p>Team management interface would be displayed here.</p>
            </div>
          )}
          
          {selectedTab === 'permissions' && (
            <div className="py-8 text-center text-gray-500 dark:text-gray-400">
              <p>Permission management interface would be displayed here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserManagement;