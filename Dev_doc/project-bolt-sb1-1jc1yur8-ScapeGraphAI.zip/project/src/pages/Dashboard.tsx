import React from 'react';
import { useTheme } from '../context/ThemeContext';
import StatCard from '../components/dashboard/StatCard';
import ChartCard from '../components/dashboard/ChartCard';
import DataTable from '../components/dashboard/DataTable';
import { useNotification } from '../context/NotificationContext';
import { 
  TrendingUp, 
  Users, 
  Database, 
  Clock,
  Zap,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  
  const showWelcomeNotification = () => {
    addNotification({
      message: 'Welcome to your analytics dashboard!',
      type: 'info',
      duration: 5000,
    });
  };

  React.useEffect(() => {
    // Show welcome notification when component mounts
    showWelcomeNotification();
  }, []);

  // Mock data for tables
  const recentQueries = [
    { id: 1, query: "Product market analysis", status: "Completed", time: "10:32 AM", runtime: "2.4s", rows: 1245 },
    { id: 2, query: "Customer segmentation", status: "Processing", time: "11:15 AM", runtime: "1.8s", rows: 876 },
    { id: 3, query: "Sales trend Q3", status: "Completed", time: "Yesterday", runtime: "3.1s", rows: 2134 },
    { id: 4, query: "New user acquisition", status: "Failed", time: "Yesterday", runtime: "-", rows: 0 },
    { id: 5, query: "Marketing ROI report", status: "Completed", time: "2 days ago", runtime: "4.5s", rows: 3567 },
  ];

  const queryColumns = [
    {
      id: 'query',
      header: 'Query Name',
      accessor: (row: any) => (
        <div>
          <p className="font-medium">{row.query}</p>
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      accessor: (row: any) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          row.status === 'Completed' 
            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
            : row.status === 'Processing' 
              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
        }`}>
          {row.status}
        </div>
      ),
    },
    {
      id: 'time',
      header: 'Time',
      accessor: (row: any) => row.time,
    },
    {
      id: 'runtime',
      header: 'Runtime',
      accessor: (row: any) => row.runtime,
    },
    {
      id: 'rows',
      header: 'Rows',
      accessor: (row: any) => row.rows.toLocaleString(),
    },
  ];

  const renderLineChart = () => {
    // This is a placeholder for a real chart implementation
    // In a real application, you would use a charting library like Chart.js, Recharts, etc.
    return (
      <div className="h-64 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 dark:text-gray-400 mb-2">This is where an actual chart would be rendered.</p>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            In a real application, you would use a charting library like Chart.js, Recharts, etc.
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="container mx-auto pb-12 pt-6 pl-20 md:pl-0">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Analytics Dashboard</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Welcome back! Here's what's happening with your data.
        </p>
      </div>
      
      <div className="flex justify-between mb-6">
        <div className="flex space-x-2">
          <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors`}>
            <Filter size={16} className="mr-2" />
            <span>Filter</span>
          </button>
          <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'} transition-colors`}>
            <Download size={16} className="mr-2" />
            <span>Export</span>
          </button>
        </div>
        <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white transition-colors`}>
          <RefreshCw size={16} className="mr-2" />
          <span>Refresh Data</span>
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Queries" 
          value="1,257" 
          icon={<TrendingUp size={20} className="text-blue-500" />}
          change={{ value: 12.5, isPositive: true }}
          color="blue"
        />
        <StatCard 
          title="Active Users" 
          value="854" 
          icon={<Users size={20} className="text-green-500" />}
          change={{ value: 8.3, isPositive: true }}
          color="green"
        />
        <StatCard 
          title="Data Sources" 
          value="37" 
          icon={<Database size={20} className="text-purple-500" />}
          change={{ value: 2.7, isPositive: true }}
          color="purple"
        />
        <StatCard 
          title="Avg Response Time" 
          value="0.82s" 
          icon={<Clock size={20} className="text-amber-500" />}
          change={{ value: 3.4, isPositive: false }}
          color="amber"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <ChartCard title="Query Performance">
            {renderLineChart()}
          </ChartCard>
        </div>
        <div>
          <ChartCard title="Data Sources">
            {renderLineChart()}
          </ChartCard>
        </div>
      </div>
      
      <div className="mb-8">
        <DataTable 
          title="Recent Queries" 
          columns={queryColumns} 
          data={recentQueries} 
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="User Activity">
          {renderLineChart()}
        </ChartCard>
        <ChartCard title="Data Source Usage">
          {renderLineChart()}
        </ChartCard>
      </div>
    </div>
  );
};

export default Dashboard;