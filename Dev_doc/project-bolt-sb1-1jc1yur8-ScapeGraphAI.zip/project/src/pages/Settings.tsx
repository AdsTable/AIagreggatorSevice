import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useUser } from '../context/UserContext';
import { Save, User, Lock, Bell, Globe, Database, Shield, ChevronRight } from 'lucide-react';

const Settings: React.FC = () => {
  const { theme } = useTheme();
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState('profile');
  
  const SettingsNavItem = ({ id, label, icon }: { id: string; label: string; icon: React.ReactNode }) => (
    <button
      className={`w-full flex items-center justify-between p-3 rounded-md transition-colors ${
        activeTab === id
          ? theme === 'dark'
            ? 'bg-gray-700 text-white'
            : 'bg-blue-50 text-blue-700'
          : theme === 'dark'
          ? 'text-gray-300 hover:bg-gray-700'
          : 'text-gray-700 hover:bg-gray-100'
      }`}
      onClick={() => setActiveTab(id)}
    >
      <div className="flex items-center">
        <span className="mr-3">{icon}</span>
        <span>{label}</span>
      </div>
      <ChevronRight size={16} />
    </button>
  );

  return (
    <div className="container mx-auto pb-12 pt-6 pl-20 md:pl-0">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Settings</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Manage your account and application preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className={`${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} p-4 rounded-lg shadow-sm`}>
          <nav className="space-y-2">
            <SettingsNavItem id="profile" label="Profile Settings" icon={<User size={20} />} />
            <SettingsNavItem id="security" label="Security" icon={<Lock size={20} />} />
            <SettingsNavItem id="notifications" label="Notifications" icon={<Bell size={20} />} />
            <SettingsNavItem id="appearance" label="Appearance" icon={<Globe size={20} />} />
            <SettingsNavItem id="dataConnections" label="Data Connections" icon={<Database size={20} />} />
            <SettingsNavItem id="permissions" label="Permissions" icon={<Shield size={20} />} />
          </nav>
        </div>

        <div className={`${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} p-6 rounded-lg shadow-sm md:col-span-3`}>
          {activeTab === 'profile' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Profile Settings</h2>
              
              <div className="mb-8">
                <div className="flex items-center mb-4">
                  <div className="h-20 w-20 rounded-full bg-blue-500 flex items-center justify-center text-white text-2xl font-medium mr-4">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h3 className="font-medium">{user?.name || 'User'}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{user?.email || 'user@example.com'}</p>
                    <button className={`mt-2 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'}`}>
                      Change profile photo
                    </button>
                  </div>
                </div>
              </div>
              
              <form>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-1`}>
                      Full Name
                    </label>
                    <input 
                      type="text" 
                      defaultValue={user?.name || 'User'}
                      className={`w-full rounded-md border ${
                        theme === 'dark' 
                          ? 'bg-gray-700 border-gray-600 text-white' 
                          : 'bg-white border-gray-300 text-gray-900'
                      } px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-1`}>
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      defaultValue={user?.email || 'user@example.com'}
                      className={`w-full rounded-md border ${
                        theme === 'dark' 
                          ? 'bg-gray-700 border-gray-600 text-white' 
                          : 'bg-white border-gray-300 text-gray-900'
                      } px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-1`}>
                      Job Title
                    </label>
                    <input 
                      type="text" 
                      defaultValue="Data Analyst"
                      className={`w-full rounded-md border ${
                        theme === 'dark' 
                          ? 'bg-gray-700 border-gray-600 text-white' 
                          : 'bg-white border-gray-300 text-gray-900'
                      } px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-1`}>
                      Department
                    </label>
                    <select 
                      className={`w-full rounded-md border ${
                        theme === 'dark' 
                          ? 'bg-gray-700 border-gray-600 text-white' 
                          : 'bg-white border-gray-300 text-gray-900'
                      } px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`} 
                    >
                      <option value="analytics">Analytics</option>
                      <option value="marketing">Marketing</option>
                      <option value="engineering">Engineering</option>
                      <option value="sales">Sales</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div className="mb-6">
                  <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-1`}>
                    Bio
                  </label>
                  <textarea 
                    rows={4}
                    className={`w-full rounded-md border ${
                      theme === 'dark' 
                        ? 'bg-gray-700 border-gray-600 text-white' 
                        : 'bg-white border-gray-300 text-gray-900'
                    } px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`} 
                  />
                </div>
                <div>
                  <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white transition-colors`}>
                    <Save size={16} className="mr-2" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {activeTab === 'appearance' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Appearance Settings</h2>
              
              <div className="mb-6">
                <label className={`block text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} mb-3`}>
                  Theme
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div 
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      theme === 'light' 
                        ? 'border-blue-500 ring-2 ring-blue-500' 
                        : theme === 'dark' 
                          ? 'border-gray-700 hover:border-gray-600' 
                          : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onClick={() => {
                      if (theme !== 'light') {
                        const { setTheme } = useTheme();
                        setTheme('light');
                      }
                    }}
                  >
                    <div className="h-24 mb-3 bg-white rounded-md shadow-sm border border-gray-200 flex flex-col">
                      <div className="h-6 bg-gray-100 border-b border-gray-200"></div>
                      <div className="flex-1 p-2">
                        <div className="w-full h-3 bg-gray-100 rounded mb-2"></div>
                        <div className="w-3/4 h-3 bg-gray-100 rounded"></div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className={`h-4 w-4 rounded-full border ${
                        theme === 'light' 
                          ? 'border-blue-500 bg-blue-500' 
                          : 'border-gray-400 bg-transparent'
                      } mr-2`}>
                        {theme === 'light' && (
                          <svg viewBox="0 0 16 16\" fill="none\" xmlns="http://www.w3.org/2000/svg\" className="h-4 w-4 text-white">
                            <path d="M13.3332 4.33331L5.99984 11.6667L2.6665 8.33331\" stroke="currentColor\" strokeWidth="1.5\" strokeLinecap="round\" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </div>
                      <span className="text-sm font-medium">Light</span>
                    </div>
                  </div>
                  
                  <div 
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      theme === 'dark' 
                        ? 'border-blue-500 ring-2 ring-blue-500' 
                        : theme === 'dark' 
                          ? 'border-gray-700 hover:border-gray-600' 
                          : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onClick={() => {
                      if (theme !== 'dark') {
                        const { setTheme } = useTheme();
                        setTheme('dark');
                      }
                    }}
                  >
                    <div className="h-24 mb-3 bg-gray-900 rounded-md shadow-sm border border-gray-700 flex flex-col">
                      <div className="h-6 bg-gray-800 border-b border-gray-700"></div>
                      <div className="flex-1 p-2">
                        <div className="w-full h-3 bg-gray-800 rounded mb-2"></div>
                        <div className="w-3/4 h-3 bg-gray-800 rounded"></div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className={`h-4 w-4 rounded-full border ${
                        theme === 'dark' 
                          ? 'border-blue-500 bg-blue-500' 
                          : 'border-gray-400 bg-transparent'
                      } mr-2`}>
                        {theme === 'dark' && (
                          <svg viewBox="0 0 16 16\" fill="none\" xmlns="http://www.w3.org/2000/svg\" className="h-4 w-4 text-white">
                            <path d="M13.3332 4.33331L5.99984 11.6667L2.6665 8.33331\" stroke="currentColor\" strokeWidth="1.5\" strokeLinecap="round\" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </div>
                      <span className="text-sm font-medium">Dark</span>
                    </div>
                  </div>
                  
                  <div className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    theme === 'dark' 
                      ? 'border-gray-700 hover:border-gray-600' 
                      : 'border-gray-300 hover:border-gray-400'
                  }`}>
                    <div className="h-24 mb-3 bg-gradient-to-r from-gray-900 to-white rounded-md shadow-sm border border-gray-300 flex flex-col">
                      <div className="h-6 bg-gradient-to-r from-gray-800 to-gray-100 border-b border-gray-400"></div>
                      <div className="flex-1 p-2">
                        <div className="w-full h-3 bg-gradient-to-r from-gray-800 to-gray-100 rounded mb-2"></div>
                        <div className="w-3/4 h-3 bg-gradient-to-r from-gray-800 to-gray-100 rounded"></div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className={`h-4 w-4 rounded-full border border-gray-400 bg-transparent mr-2`}>
                      </div>
                      <span className="text-sm font-medium">System</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className={`text-lg font-medium mb-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Color Scheme
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {['blue', 'purple', 'green', 'amber'].map((color) => (
                    <div 
                      key={color}
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        theme === 'dark' 
                          ? 'border-gray-700 hover:border-gray-600' 
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <div className={`h-8 rounded-md mb-2 ${
                        color === 'blue' ? 'bg-blue-500' : 
                        color === 'purple' ? 'bg-purple-500' : 
                        color === 'green' ? 'bg-green-500' : 
                        'bg-amber-500'
                      }`}></div>
                      <span className="text-sm font-medium capitalize">{color}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <button className={`flex items-center px-4 py-2 rounded-md ${theme === 'dark' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} text-white transition-colors`}>
                  <Save size={16} className="mr-2" />
                  <span>Save Changes</span>
                </button>
              </div>
            </div>
          )}
          
          {activeTab !== 'profile' && activeTab !== 'appearance' && (
            <div className="py-8 text-center">
              <p className={`text-lg ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} settings would be displayed here.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;